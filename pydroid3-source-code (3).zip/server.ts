import express from 'express';
import { createServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import { spawn, type ChildProcessWithoutNullStreams } from 'child_process';
import path from 'path';
import fs from 'fs';
import os from 'os';
import dotenv from 'dotenv';
import { GoogleGenAI, Type, Modality, ThinkingLevel } from '@google/genai';

dotenv.config();

// Prevent unhandled errors or rejections from terminating the dev server process
process.on('uncaughtException', (err) => {
  console.error('[Server Error] Uncaught Exception:', err);
});

process.on('unhandledRejection', (reason) => {
  console.warn('[Server Warning] Unhandled Rejection:', reason);
});

const app = express();
const server = createServer(app);
const isProd = process.env.NODE_ENV === 'production';
// In AI Studio, the application container MUST strictly listen on port 3000 in both development and production.
// Port 8080 is reserved for the platform's nginx reverse-proxy sidecar, which proxies to app-container on port 3000.
const PORT = 3000;

// Instant health check endpoints for Cloud Run & Nginx probes
app.get('/health', (req, res) => {
  res.status(200).send('OK');
});

app.get('/api/health', (req, res) => {
  res.status(200).json({ ok: true, status: 'healthy', timestamp: Date.now() });
});

// Universal CORS handler for Android APK (Capacitor/WebView) and Web
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS, HEAD');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, Accept, Origin, Cache-Control, Pragma');
  res.setHeader('Access-Control-Expose-Headers', '*');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(204);
  }
  next();
});

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Persistent Python Packages Storage in Workspace
const PYDROID_PACKAGES_DIR = path.resolve(process.cwd(), '.pydroid_packages');
const REGISTRY_FILE = path.resolve(PYDROID_PACKAGES_DIR, 'installed_packages.json');
const REQUIREMENTS_FILE = path.resolve(process.cwd(), 'requirements.txt');

try {
  if (!fs.existsSync(PYDROID_PACKAGES_DIR)) {
    fs.mkdirSync(PYDROID_PACKAGES_DIR, { recursive: true });
  }
} catch (_) {}

// Ensure PYTHONPATH globally contains .pydroid_packages for all child processes
const curPythonPath = process.env.PYTHONPATH || '';
if (!curPythonPath.includes(PYDROID_PACKAGES_DIR)) {
  process.env.PYTHONPATH = curPythonPath ? `${PYDROID_PACKAGES_DIR}:${curPythonPath}` : PYDROID_PACKAGES_DIR;
}

// Global .pth and sitecustomize registration to ensure python3 always loads .pydroid_packages
function setupPthFiles() {
  const pthTargets = [
    '/usr/local/lib/python3.10/dist-packages/pydroid.pth',
    '/usr/lib/python3/dist-packages/pydroid.pth',
    '/usr/local/lib/python3/dist-packages/pydroid.pth',
  ];
  for (const p of pthTargets) {
    try {
      const dir = path.dirname(p);
      if (fs.existsSync(dir)) {
        fs.writeFileSync(p, `${PYDROID_PACKAGES_DIR}\n`, 'utf-8');
      }
    } catch (_) {}
  }

  // Also setup sitecustomize.py so every python3 process automatically has .pydroid_packages in sys.path
  const sitecustomizeCode = `# Auto-configured by Pydroid 3 Web
import sys, os
p = '${PYDROID_PACKAGES_DIR}'
if os.path.exists(p) and p not in sys.path:
    sys.path.insert(0, p)
`;
  const siteTargets = [
    '/usr/local/lib/python3.10/dist-packages/sitecustomize.py',
    '/usr/lib/python3.10/sitecustomize.py',
  ];
  for (const s of siteTargets) {
    try {
      const dir = path.dirname(s);
      if (fs.existsSync(dir)) {
        fs.writeFileSync(s, sitecustomizeCode, 'utf-8');
      }
    } catch (_) {}
  }
}
setupPthFiles();

function loadPersistedPackages(): Array<{ name: string; version: string; installedAt?: string }> {
  try {
    if (fs.existsSync(REGISTRY_FILE)) {
      const data = JSON.parse(fs.readFileSync(REGISTRY_FILE, 'utf-8'));
      if (Array.isArray(data)) return data;
    }
  } catch (e) {
    console.log('Notice reading installed_packages.json:', e);
  }
  return [];
}

function savePersistedPackage(pkgName: string, version: string = 'installed') {
  try {
    if (!fs.existsSync(PYDROID_PACKAGES_DIR)) {
      fs.mkdirSync(PYDROID_PACKAGES_DIR, { recursive: true });
    }
    const current = loadPersistedPackages().filter((p) => p.name.toLowerCase() !== pkgName.toLowerCase());
    current.push({ name: pkgName, version, installedAt: new Date().toISOString() });
    fs.writeFileSync(REGISTRY_FILE, JSON.stringify(current, null, 2), 'utf-8');

    // Also update requirements.txt
    const reqLines = current.map((p) => (p.version && p.version !== 'installed' ? `${p.name}==${p.version}` : p.name));
    fs.writeFileSync(REQUIREMENTS_FILE, reqLines.join('\n') + '\n', 'utf-8');
    setupPthFiles();
  } catch (e) {
    console.log('Notice saving to installed_packages.json:', e);
  }
}

function removePersistedPackage(pkgName: string) {
  try {
    const current = loadPersistedPackages().filter((p) => p.name.toLowerCase() !== pkgName.toLowerCase());
    fs.writeFileSync(REGISTRY_FILE, JSON.stringify(current, null, 2), 'utf-8');
    const reqLines = current.map((p) => (p.version && p.version !== 'installed' ? `${p.name}==${p.version}` : p.name));
    fs.writeFileSync(REQUIREMENTS_FILE, reqLines.join('\n') + '\n', 'utf-8');
  } catch (e) {
    console.log('Notice removing from installed_packages.json:', e);
  }
}

// Auto-install missing module on-the-fly when code execution catches ModuleNotFoundError
async function autoInstallMissingModule(modName: string): Promise<boolean> {
  const cleanMod = modName.trim().replace(/^['"]+|['"]+$/g, '');
  if (!/^[a-zA-Z0-9_\-]+$/.test(cleanMod)) return false;

  console.log(`[Auto-Fix] Phát hiện thiếu thư viện '${cleanMod}'. Đang tự động khôi phục tức thời...`);
  await ensurePipReady(true);

  return new Promise((resolve) => {
    const py = spawn('python3', [
      '-m',
      'pip',
      'install',
      '--target',
      PYDROID_PACKAGES_DIR,
      '--prefer-binary',
      '--no-cache-dir',
      '--no-warn-script-location',
      cleanMod,
      '--break-system-packages',
    ], {
      env: { ...process.env, PYTHONPATH: PYDROID_PACKAGES_DIR },
    });
    py.on('close', (code) => {
      if (code === 0) {
        savePersistedPackage(cleanMod, 'installed');
        setupPthFiles();
        resolve(true);
      } else {
        resolve(false);
      }
    });
    py.on('error', () => resolve(false));
  });
}

// Background sync on startup to guarantee pyfiglet and all packages are ready
async function syncPersistentPackages() {
  setupPthFiles();
  await ensurePipReady(true);

  const persisted = loadPersistedPackages();
  // Ensure pyfiglet is registered
  if (!persisted.some((p) => p.name.toLowerCase() === 'pyfiglet')) {
    savePersistedPackage('pyfiglet', '1.0.4');
  }
  // Ensure colorama is registered
  if (!persisted.some((p) => p.name.toLowerCase() === 'colorama')) {
    savePersistedPackage('colorama', '0.4.6');
  }

  const allPackages = loadPersistedPackages();
  for (const item of allPackages) {
    const pkgDir = path.join(PYDROID_PACKAGES_DIR, item.name);
    if (!fs.existsSync(pkgDir)) {
      console.log(`[Startup Sync] Tự động phục hồi thư viện ${item.name} (${item.version})...`);
      await new Promise<void>((resolve) => {
        const py = spawn('python3', [
          '-m',
          'pip',
          'install',
          '--target',
          PYDROID_PACKAGES_DIR,
          '--prefer-binary',
          '--no-cache-dir',
          '--no-warn-script-location',
          item.name,
          '--break-system-packages',
        ], {
          env: { ...process.env, PYTHONPATH: PYDROID_PACKAGES_DIR },
        });
        py.on('close', () => resolve());
        py.on('error', () => resolve());
      });
    }
  }
}
syncPersistentPackages().catch(() => {});

// Ensure any imported third-party modules (like pyfiglet) are ready before execution
async function ensureImportedModulesReady(code: string) {
  setupPthFiles();
  const match = code.match(/(?:^|\n)\s*(?:import|from)\s+([a-zA-Z0-9_]+)/g);
  if (!match) return;
  const mods = match.map((m) => m.replace(/^(?:\n|\s)*(?:import|from)\s+/, '').trim());
  const persisted = loadPersistedPackages();
  const knownMods = new Set<string>(['pyfiglet', 'colorama']);
  for (const p of persisted) {
    if (p && p.name) knownMods.add(p.name.toLowerCase());
  }

  for (const mod of mods) {
    const lower = mod.toLowerCase();
    if (knownMods.has(lower)) {
      const p = path.join(PYDROID_PACKAGES_DIR, mod);
      if (!fs.existsSync(p)) {
        await autoInstallMissingModule(mod);
      }
    }
  }
}

// Enable CORS and Cross-Origin headers for API and iframe compatibility
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', '*');
  res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(204);
  }
  next();
});

// Serve local Pyodide WebAssembly package statically with correct MIME types and CORS
// Serve local Pyodide WebAssembly package statically with correct MIME types and CORS
const pyodidePath = path.join(process.cwd(), 'node_modules/pyodide');

// Background check to ensure essential micropip and packaging wheels exist in node_modules/pyodide
async function ensureEssentialPyodideWheels() {
  if (!fs.existsSync(pyodidePath)) return;
  const wheels = [
    { name: 'micropip-0.6.0-py3-none-any.whl', url: 'https://cdn.jsdelivr.net/pyodide/v0.26.4/full/micropip-0.6.0-py3-none-any.whl' },
    { name: 'packaging-23.2-py3-none-any.whl', url: 'https://cdn.jsdelivr.net/pyodide/v0.26.4/full/packaging-23.2-py3-none-any.whl' },
  ];
  for (const w of wheels) {
    const dest = path.join(pyodidePath, w.name);
    if (!fs.existsSync(dest)) {
      try {
        const resp = await fetch(w.url);
        if (resp.ok) {
          const buf = Buffer.from(await resp.arrayBuffer());
          fs.writeFileSync(dest, buf);
        }
      } catch (_) {}
    }
  }
}
ensureEssentialPyodideWheels().catch(() => {});

if (fs.existsSync(pyodidePath)) {
  app.use('/pyodide', (req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
    res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
    next();
  }, express.static(pyodidePath, {
    maxAge: '1y',
    setHeaders: (res, filePath) => {
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', '*');
      res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
      if (filePath.endsWith('.wasm')) {
        res.setHeader('Content-Type', 'application/wasm');
      } else if (filePath.endsWith('.js') || filePath.endsWith('.mjs')) {
        res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
      } else if (filePath.endsWith('.zip')) {
        res.setHeader('Content-Type', 'application/zip');
      } else if (filePath.endsWith('.whl')) {
        res.setHeader('Content-Type', 'application/octet-stream');
      } else if (filePath.endsWith('.json')) {
        res.setHeader('Content-Type', 'application/json; charset=utf-8');
      }
    },
  }));

  // Fallback for any wheel or package not found locally in node_modules/pyodide:
  // Redirect to jsDelivr CDN instead of letting SPA catch-all serve index.html!
  app.get('/pyodide/:file', (req, res) => {
    const filename = req.params.file;
    return res.redirect(302, `https://cdn.jsdelivr.net/pyodide/v0.26.4/full/${encodeURIComponent(filename)}`);
  });
}

function isValidGeminiKeyFormat(key: string): boolean {
  if (!key) return false;
  const s = key.replace(/[\s\u200B-\u200D\uFEFF'"]+/g, '');
  if (s.includes('...') || s.includes('MY_GEMINI') || s.includes('YOUR_API')) {
    return false;
  }
  return /^[A-Za-z0-9_-]{20,}$/.test(s);
}

// Initialize Gemini API dynamically so updated environment variables are always honored
function getServerEnvGeminiKey(): string {
  const raw = (process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || '').replace(
    /[\s\u200B-\u200D\uFEFF'"]+/g,
    ''
  );
  return isValidGeminiKeyFormat(raw) ? raw : '';
}

let cachedClientKey = getServerEnvGeminiKey();
let ai = new GoogleGenAI({
  apiKey: cachedClientKey || undefined,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

function getActiveAiInstance(): { client: GoogleGenAI; key: string } {
  const currentKey = getServerEnvGeminiKey();
  if (currentKey !== cachedClientKey) {
    cachedClientKey = currentKey;
    ai = new GoogleGenAI({
      apiKey: cachedClientKey || undefined,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return { client: ai, key: currentKey };
}

// Setup WebSocket servers: Python Execution and Live AI Session
const pythonWss = new WebSocketServer({ noServer: true });
const liveAiWss = new WebSocketServer({ noServer: true });

server.on('upgrade', (request, socket, head) => {
  const urlStr = request.url || '';
  if (urlStr.includes('/api/python/ws')) {
    pythonWss.handleUpgrade(request, socket, head, (ws) => {
      pythonWss.emit('connection', ws, request);
    });
  } else if (urlStr.includes('/api/ai/live')) {
    liveAiWss.handleUpgrade(request, socket, head, (ws) => {
      liveAiWss.emit('connection', ws, request);
    });
  } else {
    socket.destroy();
  }
});

// Interface for HTTP Streaming Session
interface PythonSession {
  id: string;
  process: ChildProcessWithoutNullStreams;
  tempFilePath: string;
  startTime: number;
  outputBuffer: Array<any>;
  resListener: express.Response | null;
  isFinished: boolean;
}

const activeSessions = new Map<string, PythonSession>();

// REST endpoints for reliable HTTP-based Real-time Execution
app.post('/api/python/session/start', async (req, res) => {
  const { code, stdin = '' } = req.body;
  if (typeof code !== 'string') {
    return res.status(400).json({ error: 'Mã nguồn không hợp lệ' });
  }

  await ensureImportedModulesReady(code);

  const sessionId = `sess_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const tempId = `pydroid_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.py`;
  const tempFilePath = path.join(os.tmpdir(), tempId);

  try {
    fs.writeFileSync(tempFilePath, code, 'utf-8');
    const startTime = Date.now();

    const py = spawn('python3', ['-u', tempFilePath], {
      env: {
        ...process.env,
        PYTHONPATH: process.env.PYTHONPATH || PYDROID_PACKAGES_DIR,
        PYTHONUNBUFFERED: '1',
        PYTHONDONTWRITEBYTECODE: '1',
        LC_ALL: 'en_US.UTF-8',
        LANG: 'en_US.UTF-8',
      },
    });

    if (stdin && py.stdin) {
      py.stdin.write(stdin);
      if (!stdin.endsWith('\n')) py.stdin.write('\n');
    }

    const session: PythonSession = {
      id: sessionId,
      process: py,
      tempFilePath,
      startTime,
      outputBuffer: [],
      resListener: null,
      isFinished: false,
    };

    const emitEvent = (event: any) => {
      session.outputBuffer.push(event);
      if (session.resListener && !session.resListener.writableEnded) {
        session.resListener.write(`data: ${JSON.stringify(event)}\n\n`);
      }
    };

    py.stdout.on('data', (chunk) => {
      emitEvent({ type: 'stdout', data: chunk.toString('utf-8') });
    });

    py.stderr.on('data', (chunk) => {
      emitEvent({ type: 'stderr', data: chunk.toString('utf-8') });
    });

    py.on('close', (code, signal) => {
      const executionTimeMs = Date.now() - startTime;
      session.isFinished = true;
      emitEvent({
        type: 'exit',
        code: code !== null ? code : (signal ? 137 : 0),
        signal: signal || null,
        executionTimeMs,
      });

      try {
        if (fs.existsSync(tempFilePath)) fs.unlinkSync(tempFilePath);
      } catch (e) {
        // ignore
      }

      if (session.resListener && !session.resListener.writableEnded) {
        session.resListener.end();
      }

      setTimeout(() => {
        activeSessions.delete(sessionId);
      }, 30000);
    });

    py.on('error', (err) => {
      session.isFinished = true;
      emitEvent({ type: 'error', data: `Lỗi khởi chạy Python: ${err.message}` });
      try {
        if (fs.existsSync(tempFilePath)) fs.unlinkSync(tempFilePath);
      } catch (e) {
        // ignore
      }
      if (session.resListener && !session.resListener.writableEnded) {
        session.resListener.end();
      }
      activeSessions.delete(sessionId);
    });

    activeSessions.set(sessionId, session);
    res.json({ sessionId });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// SSE event stream endpoint
app.get('/api/python/session/:sessionId/events', (req, res) => {
  const { sessionId } = req.params;
  const session = activeSessions.get(sessionId);

  if (!session) {
    return res.status(404).json({ error: 'Không tìm thấy phiên thực thi' });
  }

  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders?.();

  session.resListener = res;

  // Flush buffer to client
  for (const ev of session.outputBuffer) {
    res.write(`data: ${JSON.stringify(ev)}\n\n`);
  }

  if (session.isFinished) {
    res.end();
  }

  req.on('close', () => {
    if (session.resListener === res) {
      session.resListener = null;
    }
  });
});

// Interactive STDIN endpoint for live input()
app.post('/api/python/session/:sessionId/input', (req, res) => {
  const { sessionId } = req.params;
  const { data = '' } = req.body;
  const session = activeSessions.get(sessionId);

  if (!session || session.isFinished) {
    return res.status(404).json({ error: 'Phiên thực thi đã kết thúc hoặc không tồn tại' });
  }

  if (session.process.stdin && !session.process.stdin.destroyed) {
    session.process.stdin.write(data);
    if (!data.endsWith('\n')) {
      session.process.stdin.write('\n');
    }
  }

  res.json({ success: true });
});

// Stop session endpoint
app.post('/api/python/session/:sessionId/stop', (req, res) => {
  const { sessionId } = req.params;
  const session = activeSessions.get(sessionId);

  if (session) {
    try {
      session.process.kill('SIGKILL');
    } catch (e) {
      // ignore
    }
    try {
      if (fs.existsSync(session.tempFilePath)) fs.unlinkSync(session.tempFilePath);
    } catch (e) {
      // ignore
    }
    activeSessions.delete(sessionId);
  }

  res.json({ success: true });
});

// Track active Python process per WS connection
pythonWss.on('connection', (ws: WebSocket) => {
  let pyProcess: ChildProcessWithoutNullStreams | null = null;
  let tempFilePath: string | null = null;
  const startTime = Date.now();

  const cleanup = () => {
    if (pyProcess) {
      try {
        pyProcess.kill('SIGKILL');
      } catch (err) {
        // ignore
      }
      pyProcess = null;
    }
    if (tempFilePath && fs.existsSync(tempFilePath)) {
      try {
        fs.unlinkSync(tempFilePath);
      } catch (err) {
        // ignore
      }
      tempFilePath = null;
    }
  };

  ws.on('message', async (messageRaw) => {
    try {
      const msg = JSON.parse(messageRaw.toString());

      if (msg.type === 'run') {
        cleanup();

        const code = msg.code || '';
        const initialStdin = msg.stdin || '';

        await ensureImportedModulesReady(code);

        // Write code to a secure temporary file
        const tempId = `pydroid_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.py`;
        tempFilePath = path.join(os.tmpdir(), tempId);
        fs.writeFileSync(tempFilePath, code, 'utf-8');

        const runStart = Date.now();
        // Use python3 with unbuffered IO (-u)
        pyProcess = spawn('python3', ['-u', tempFilePath], {
          env: {
            ...process.env,
            PYTHONPATH: process.env.PYTHONPATH || PYDROID_PACKAGES_DIR,
            PYTHONUNBUFFERED: '1',
            PYTHONDONTWRITEBYTECODE: '1',
            LC_ALL: 'en_US.UTF-8',
            LANG: 'en_US.UTF-8',
          },
        });

        // If user provided initial STDIN data
        if (initialStdin && pyProcess.stdin) {
          pyProcess.stdin.write(initialStdin);
          if (!initialStdin.endsWith('\n')) {
            pyProcess.stdin.write('\n');
          }
        }

        pyProcess.stdout.on('data', (chunk) => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({
              type: 'stdout',
              data: chunk.toString('utf-8'),
            }));
          }
        });

        pyProcess.stderr.on('data', (chunk) => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({
              type: 'stderr',
              data: chunk.toString('utf-8'),
            }));
          }
        });

        pyProcess.on('close', (code, signal) => {
          const executionTimeMs = Date.now() - runStart;
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({
              type: 'exit',
              code: code !== null ? code : (signal ? 137 : 0),
              signal: signal || null,
              executionTimeMs,
            }));
          }
          cleanup();
        });

        pyProcess.on('error', (err) => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({
              type: 'error',
              data: `Không thể khởi chạy Python: ${err.message}`,
            }));
          }
          cleanup();
        });

      } else if (msg.type === 'stdin') {
        if (pyProcess && pyProcess.stdin && !pyProcess.stdin.destroyed) {
          const inputData = msg.data || '';
          pyProcess.stdin.write(inputData);
          if (!inputData.endsWith('\n')) {
            pyProcess.stdin.write('\n');
          }
        }
      } else if (msg.type === 'kill') {
        cleanup();
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({
            type: 'exit',
            code: 130,
            signal: 'SIGINT',
            executionTimeMs: Date.now() - startTime,
            stopped: true,
          }));
        }
      }
    } catch (e: any) {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'error', data: e?.message || 'Lỗi xử lý yêu cầu' }));
      }
    }
  });

  ws.on('close', () => {
    cleanup();
  });

  ws.on('error', () => {
    cleanup();
  });
});

// Live API WebSocket connection for real-time bidirectional audio & text (gemini-3.8-live)
liveAiWss.on('connection', async (ws: WebSocket) => {
  const { client: liveAi, key: activeLiveKey } = getActiveAiInstance();
  if (!activeLiveKey) {
    ws.send(JSON.stringify({ error: 'Máy chủ chưa được cấu hình GEMINI_API_KEY hợp lệ trong AI Studio Secrets hoặc Render Environment.' }));
    ws.close();
    return;
  }

  let session: any = null;
  let isClosed = false;

  try {
    session = await liveAi.live.connect({
      model: 'gemini-3.8-live',
      callbacks: {
        onopen: () => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: 'connected', message: 'Kết nối Live API thành công' }));
          }
        },
        onmessage: (e: any) => {
          if (!isClosed && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify(e));
          }
        },
        onerror: (err: any) => {
          if (!isClosed && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ error: err?.message || 'Lỗi Live API' }));
          }
        },
        onclose: () => {
          if (!isClosed && ws.readyState === WebSocket.OPEN) {
            ws.close();
          }
        },
      },
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {
              voiceName: 'Puck',
            },
          },
        },
        systemInstruction: {
          parts: [
            {
              text: 'Bạn là Trợ lý AI Lập trình Python thông minh trên Pydroid 3 Web. Hỗ trợ người dùng qua giọng nói và văn bản thời gian thực bằng tiếng Việt thân thiện, súc tích và chuẩn xác.',
            },
          ],
        },
      },
    });

    ws.on('message', async (raw) => {
      try {
        const payload = JSON.parse(raw.toString());
        if (session && !isClosed) {
          await session.send(payload);
        }
      } catch (err: any) {
        console.log('[Live API] Gói tin từ client:', err?.message);
      }
    });

    ws.on('close', () => {
      isClosed = true;
      if (session) {
        try { session.close(); } catch (_) {}
      }
    });

    ws.on('error', () => {
      isClosed = true;
      if (session) {
        try { session.close(); } catch (_) {}
      }
    });
  } catch (connectErr: any) {
    console.log('[Live API] Thông báo kết nối Live API:', connectErr?.message || connectErr);
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ error: `Không thể kết nối Live API: ${connectErr?.message || 'Lỗi kết nối'}` }));
      ws.close();
    }
  }
});

// REST endpoint: Direct run (fallback or non-websocket run)
app.post('/api/python/run', async (req, res) => {
  const { code, stdin = '' } = req.body;
  if (typeof code !== 'string') {
    return res.status(400).json({ error: 'Mã nguồn Python không hợp lệ' });
  }

  await ensureImportedModulesReady(code);

  const tempId = `pydroid_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.py`;
  const tempFilePath = path.join(os.tmpdir(), tempId);

  try {
    fs.writeFileSync(tempFilePath, code, 'utf-8');
    const startTime = Date.now();

    const py = spawn('python3', ['-u', tempFilePath], {
      env: {
        ...process.env,
        PYTHONPATH: process.env.PYTHONPATH || PYDROID_PACKAGES_DIR,
        PYTHONUNBUFFERED: '1',
        PYTHONDONTWRITEBYTECODE: '1',
      },
      timeout: 15000,
    });

    let stdout = '';
    let stderr = '';

    if (stdin) {
      py.stdin.write(stdin);
      if (!stdin.endsWith('\n')) py.stdin.write('\n');
      py.stdin.end();
    } else {
      py.stdin.end();
    }

    py.stdout.on('data', (data) => {
      stdout += data.toString('utf-8');
    });

    py.stderr.on('data', (data) => {
      stderr += data.toString('utf-8');
    });

    py.on('close', (code, signal) => {
      const executionTimeMs = Date.now() - startTime;
      try {
        if (fs.existsSync(tempFilePath)) fs.unlinkSync(tempFilePath);
      } catch (e) {
        // ignore
      }
      res.json({
        stdout,
        stderr,
        exitCode: code !== null ? code : (signal ? 137 : 0),
        signal,
        executionTimeMs,
      });
    });

    py.on('error', (err) => {
      try {
        if (fs.existsSync(tempFilePath)) fs.unlinkSync(tempFilePath);
      } catch (e) {
        // ignore
      }
      res.status(500).json({ error: err.message, stdout, stderr });
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// REST endpoint: Direct download a single Python file (.py) with Content-Disposition attachment for mobile & web
app.get('/api/project/download-file', (req, res) => {
  const name = (req.query.name as string) || 'main.py';
  const cleanName = (name.endsWith('.py') ? name : `${name}.py`).replace(/[^a-zA-Z0-9._\-]/g, '_');
  const content = (req.query.content as string) || '';

  res.setHeader('Content-Type', 'application/octet-stream');
  res.setHeader('Content-Disposition', `attachment; filename="${cleanName}"`);
  res.setHeader('Content-Length', Buffer.byteLength(content, 'utf-8'));
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.send(content);
});

app.post('/api/project/download-file', (req, res) => {
  const { name = 'main.py', content = '' } = req.body;
  const cleanName = (name.endsWith('.py') ? name : `${name}.py`).replace(/[^a-zA-Z0-9._\-]/g, '_');

  res.setHeader('Content-Type', 'application/octet-stream');
  res.setHeader('Content-Disposition', `attachment; filename="${cleanName}"`);
  res.setHeader('Content-Length', Buffer.byteLength(content, 'utf-8'));
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.send(content);
});

// REST endpoint: Export complete source code as a ZIP archive for GitHub / Android APK building
app.get('/api/project/export-zip', (req, res) => {
  const zipPath = path.join(os.tmpdir(), `pydroid3_source_${Date.now()}.zip`);
  const rootDir = process.cwd();

  const pythonZipScript = `
import os, zipfile

dest_zip = r"${zipPath}"
root_dir = r"${rootDir}"
exclude_dirs = {"node_modules", "dist", ".pydroid_packages", "tmp", ".git", "__pycache__"}

with zipfile.ZipFile(dest_zip, "w", zipfile.ZIP_DEFLATED) as z:
    for dirpath, dirnames, filenames in os.walk(root_dir):
        dirnames[:] = [d for d in dirnames if d not in exclude_dirs]
        for f in filenames:
            if f.endswith('.pyc') or f.endswith('.log') or f.endswith('.tmp') or f == 'bun.lock':
                continue
            full_path = os.path.join(dirpath, f)
            rel_path = os.path.relpath(full_path, root_dir)
            z.write(full_path, rel_path)
`;

  try {
    const py = spawn('python3', ['-c', pythonZipScript]);
    py.on('close', (code) => {
      if (code === 0 && fs.existsSync(zipPath)) {
        const fileStat = fs.statSync(zipPath);

        // Support JSON base64 format for 100% reliable download inside iframes and Android browsers
        if (req.query.format === 'base64') {
          const fileBuf = fs.readFileSync(zipPath);
          try { fs.unlinkSync(zipPath); } catch (_) {}
          return res.json({
            success: true,
            filename: 'pydroid3-source-code.zip',
            size: fileStat.size,
            base64: fileBuf.toString('base64'),
          });
        }

        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', 'attachment; filename="pydroid3-source-code.zip"');
        res.setHeader('Content-Length', fileStat.size);
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
        const stream = fs.createReadStream(zipPath);
        stream.pipe(res);
        stream.on('end', () => {
          try { fs.unlinkSync(zipPath); } catch (_) {}
        });
      } else {
        res.status(500).json({ error: 'Không thể tạo file zip mã nguồn' });
      }
    });
    py.on('error', (err) => {
      res.status(500).json({ error: err.message });
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Helper for Vietnamese translation of Python compile syntax errors
function translatePythonCompileError(type: string, message: string): string {
  const msgLower = (message || '').toLowerCase();
  if (msgLower.includes("expected ':'")) {
    return "Thiếu dấu hai chấm ':' ở cuối câu lệnh";
  }
  if (msgLower.includes('expected an indented block')) {
    return 'Thiếu khối lệnh thụt lề (cần thụt lề 4 khoảng trắng)';
  }
  if (msgLower.includes('unexpected indent')) {
    return 'Thụt lề không hợp lệ (thụt lề thừa hoặc sai cấp độ)';
  }
  if (msgLower.includes('unindent does not match any outer indentation level')) {
    return 'Thụt lề lùi về không khớp với bất kỳ khối lệnh ngoài nào';
  }
  if (msgLower.includes("unmatched ')'") || msgLower.includes("unmatched ']'") || msgLower.includes("unmatched '}'")) {
    return "Dấu đóng ngoặc thừa hoặc không khớp với dấu mở ngoặc trước đó";
  }
  if (msgLower.includes('was never closed')) {
    return 'Chưa đóng ngoặc hoặc dấu nháy tương ứng';
  }
  if (msgLower.includes('unterminated string') || msgLower.includes('eol while scanning string')) {
    return 'Chưa đóng chuỗi ký tự (thiếu dấu nháy đơn hoặc nháy kép)';
  }
  if (msgLower.includes('cannot assign to')) {
    return 'Không thể gán giá trị cho biểu thức này (vế trái phải là biến)';
  }
  if (msgLower.includes('invalid syntax')) {
    return 'Cú pháp Python không hợp lệ hoặc gõ nhầm ký tự';
  }
  if (type === 'IndentationError') {
    return `Lỗi thụt lề: ${message}`;
  }
  if (type === 'TabError') {
    return 'Lỗi trộn lẫn phím Tab và khoảng trắng';
  }
  return message || 'Lỗi cú pháp Python';
}

// REST endpoint: Fast Python Background Linter
app.post('/api/python/lint', (req, res) => {
  const { code } = req.body;
  if (typeof code !== 'string') {
    return res.status(400).json({ error: 'Mã không hợp lệ' });
  }

  if (!code.trim()) {
    return res.json({ valid: true, errors: [] });
  }

  const py = spawn('python3', [
    '-c',
    `
import sys, json

code = sys.stdin.read()
try:
    compile(code, '<string>', 'exec')
    print(json.dumps({'valid': True, 'errors': []}))
except (SyntaxError, IndentationError, TabError) as e:
    line = e.lineno or 1
    col = e.offset or 1
    end_line = getattr(e, 'end_lineno', line)
    end_col = getattr(e, 'end_offset', col + 1)
    msg = str(e.msg) if hasattr(e, 'msg') else str(e)
    text = (e.text or '').strip()
    
    print(json.dumps({
        'valid': False,
        'errors': [{
            'line': line,
            'column': col,
            'endLine': end_line,
            'endColumn': end_col,
            'type': type(e).__name__,
            'message': msg,
            'text': text
        }]
    }))
except Exception as e:
    print(json.dumps({
        'valid': False,
        'errors': [{
            'line': 1,
            'column': 1,
            'type': type(e).__name__,
            'message': str(e)
        }]
    }))
`,
  ]);

  let stdoutData = '';

  py.stdin.write(code);
  py.stdin.end();

  py.stdout.on('data', (chunk) => {
    stdoutData += chunk.toString('utf-8');
  });

  const timer = setTimeout(() => {
    py.kill();
    res.json({ valid: true, errors: [] });
  }, 1200);

  py.on('close', () => {
    clearTimeout(timer);
    try {
      const result = JSON.parse(stdoutData.trim());
      if (result.errors && Array.isArray(result.errors)) {
        result.errors = result.errors.map((err: any) => ({
          ...err,
          vietnameseMessage: translatePythonCompileError(err.type, err.message),
        }));
      }
      res.json(result);
    } catch (e) {
      res.json({ valid: true, errors: [] });
    }
  });

  py.on('error', () => {
    clearTimeout(timer);
    res.json({ valid: true, errors: [] });
  });
});

// REST endpoint: System & AI Gateway Health Check for Android APK & Web
app.get('/api/system/status', (req, res) => {
  res.json({
    status: 'ok',
    server: 'Pydroid 3 Cloud Backend',
    uptime: Math.round(process.uptime()),
    timestamp: Date.now(),
    features: {
      geminiAi: Boolean(getServerEnvGeminiKey()),
      cpythonNative: true,
      websocketStreaming: true,
      apkApiGateway: true,
    },
  });
});

// REST endpoint: Python Environment Version Info
app.get('/api/python/version', (req, res) => {
  const py = spawn('python3', [
    '-c',
    'import sys, platform; print(f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}|{platform.system()}|{platform.machine()}|{sys.version}")',
  ]);

  let stdoutData = '';
  py.stdout.on('data', (chunk) => {
    stdoutData += chunk.toString('utf-8');
  });

  const timer = setTimeout(() => {
    py.kill();
    res.json({
      cpython: {
        version: '3.10.12',
        full: 'CPython 3.10.12',
        system: 'Linux x86_64',
        details: 'CPython 3.10.12 (Native Linux 64-bit)',
      },
      pyodide: {
        version: '3.12.7',
        pyodideVersion: '0.26.4',
        full: 'Python 3.12.7 (Pyodide v0.26.4)',
        system: 'WebAssembly (WASM)',
        details: 'Pyodide WASM (Python 3.12.7 Local)',
      },
    });
  }, 1000);

  py.on('close', () => {
    clearTimeout(timer);
    const parts = stdoutData.trim().split('|');
    const version = parts[0] || '3.10.12';
    const osName = parts[1] || 'Linux';
    const arch = parts[2] || 'x86_64';
    const rawVersion = parts[3] || `3.10.12 (${osName})`;

    res.json({
      cpython: {
        version,
        full: `CPython ${version}`,
        system: `${osName} ${arch}`,
        details: `CPython ${version} (${osName} ${arch} Native)`,
        rawVersion,
      },
      pyodide: {
        version: '3.12.7',
        pyodideVersion: '0.26.4',
        full: 'Python 3.12.7 (Pyodide v0.26.4)',
        system: 'WebAssembly (WASM)',
        details: 'Pyodide WASM (Python 3.12.7 Local)',
      },
    });
  });

  py.on('error', () => {
    clearTimeout(timer);
    res.json({
      cpython: {
        version: '3.10.12',
        full: 'CPython 3.10.12',
        system: 'Linux x86_64',
        details: 'CPython 3.10.12 (Native Linux 64-bit)',
      },
      pyodide: {
        version: '3.12.7',
        pyodideVersion: '0.26.4',
        full: 'Python 3.12.7 (Pyodide v0.26.4)',
        system: 'WebAssembly (WASM)',
        details: 'Pyodide WASM (Python 3.12.7 Local)',
      },
    });
  });
});

// Helper to ensure pip is ready and functional with auto-healing bootstrap
let pipBootstrapPromise: Promise<boolean> | null = null;

function ensurePipReady(autoBootstrap = false): Promise<boolean> {
  if (pipBootstrapPromise) return pipBootstrapPromise;

  pipBootstrapPromise = (async () => {
    // 1. Check if pip is already working
    const isWorking = await new Promise<boolean>((resolve) => {
      try {
        const chk = spawn('python3', ['-m', 'pip', '--version']);
        const timer = setTimeout(() => {
          try { chk.kill(); } catch (_) {}
          resolve(false);
        }, 3000);
        chk.on('close', (code) => {
          clearTimeout(timer);
          resolve(code === 0);
        });
        chk.on('error', () => {
          clearTimeout(timer);
          resolve(false);
        });
      } catch (_) {
        resolve(false);
      }
    });

    if (isWorking) return true;
    if (!autoBootstrap) return false;

    // 2. Pip is missing: Bootstrap get-pip.py safely
    console.log('[Pip Bootstrapper] pip chưa được cài đặt trong môi trường CPython. Đang tự động bootstrap...');
    const bootstrapped = await new Promise<boolean>((resolve) => {
      const boot = spawn('bash', [
        '-c',
        'curl -sS https://bootstrap.pypa.io/get-pip.py -o /tmp/get-pip.py && python3 /tmp/get-pip.py --break-system-packages --no-warn-script-location',
      ]);
      const timer = setTimeout(() => {
        try { boot.kill(); } catch (_) {}
        resolve(false);
      }, 60000);
      boot.on('close', (code) => {
        clearTimeout(timer);
        resolve(code === 0);
      });
      boot.on('error', () => {
        clearTimeout(timer);
        resolve(false);
      });
    });

    return bootstrapped;
  })().finally(() => {
    pipBootstrapPromise = null;
  });

  return pipBootstrapPromise;
}

// REST endpoint: List installed Python packages (combining system pip list and persistent workspace packages)
app.get('/api/python/packages', async (req, res) => {
  await ensurePipReady(true);

  const persisted = loadPersistedPackages();

  const py = spawn('python3', ['-m', 'pip', 'list', '--format=json'], {
    env: { ...process.env, PIP_DISABLE_PIP_VERSION_CHECK: '1', PIP_NO_COLOR: '1' },
  });
  let stdoutData = '';
  let stderrData = '';

  py.stdout.on('data', (chunk) => {
    stdoutData += chunk.toString('utf-8');
  });
  py.stderr.on('data', (chunk) => {
    stderrData += chunk.toString('utf-8');
  });

  const timer = setTimeout(() => {
    try { py.kill(); } catch (_) {}
    res.json({ success: true, packages: persisted });
  }, 10000);

  py.on('close', (code) => {
    clearTimeout(timer);
    let pipPackages: Array<{ name: string; version: string }> = [];
    try {
      pipPackages = JSON.parse(stdoutData.trim() || '[]');
    } catch (e) {
      const lines = stdoutData.split('\n').filter(Boolean).slice(2);
      pipPackages = lines.map((l) => {
        const parts = l.trim().split(/\s+/);
        return { name: parts[0], version: parts[1] || 'installed' };
      }).filter((p) => p.name);
    }

    // Merge pipPackages and persisted packages
    const pkgMap = new Map<string, { name: string; version: string }>();
    for (const p of pipPackages) {
      if (p && p.name) pkgMap.set(p.name.toLowerCase(), { name: p.name, version: p.version || 'installed' });
    }
    for (const p of persisted) {
      if (p && p.name && !pkgMap.has(p.name.toLowerCase())) {
        pkgMap.set(p.name.toLowerCase(), { name: p.name, version: p.version || 'installed' });
      }
    }

    res.json({ success: true, packages: Array.from(pkgMap.values()) });
  });

  py.on('error', () => {
    clearTimeout(timer);
    res.json({ success: true, packages: persisted });
  });
});

// REST endpoint: Install or update Python package with workspace persistence
app.post('/api/python/packages/install', async (req, res) => {
  const { name, upgrade } = req.body;
  if (!name || typeof name !== 'string') {
    return res.status(400).json({ success: false, error: 'Thiếu tên thư viện' });
  }

  // Clean and sanitize input: strip "pip install", "pip3 install", "python -m pip install", quotes
  let rawName = name.trim();
  rawName = rawName.replace(/^(python3?\s+-m\s+pip\s+install|pip3?\s+install)\s+/i, '').trim();
  rawName = rawName.replace(/^['"]+|['"]+$/g, '').trim();

  // Validate package tokens
  const pkgTokens = rawName.split(/\s+/).filter(Boolean);
  const isValid = pkgTokens.length > 0 && pkgTokens.every((tok) => /^[a-zA-Z0-9_\-\.\=\>\<\[\],!~]+$/.test(tok));
  if (!isValid) {
    return res.status(400).json({ success: false, error: 'Tên thư viện chứa ký tự không hợp lệ' });
  }

  const pipReady = await ensurePipReady(true);
  if (!pipReady) {
    return res.status(500).json({
      success: false,
      error: 'Không thể khởi tạo công cụ Pip trong hệ sinh thái CPython',
      output: '❌ Không thể tải hoặc cấu hình công cụ pip. Vui lòng thử lại sau giây lát.',
    });
  }

  // Helper to run pip install into both system and persistent workspace target
  const runPip = (extraFlags: string[] = []): Promise<{ code: number | null; output: string }> => {
    return new Promise((resolve) => {
      const args = [
        '-m',
        'pip',
        'install',
        '--target',
        PYDROID_PACKAGES_DIR,
        '--prefer-binary',
        '--no-cache-dir',
        '--no-warn-script-location',
        '--timeout',
        '120',
        '--retries',
        '3',
        ...extraFlags,
      ];
      if (upgrade) {
        args.push('--upgrade');
      }
      args.push(...pkgTokens, '--break-system-packages');

      const py = spawn('python3', args, {
        env: {
          ...process.env,
          PYTHONUNBUFFERED: '1',
          PIP_DISABLE_PIP_VERSION_CHECK: '1',
          PIP_NO_COLOR: '1',
        },
      });

      let out = '';
      py.stdout.on('data', (chunk) => {
        out += chunk.toString('utf-8');
      });
      py.stderr.on('data', (chunk) => {
        out += chunk.toString('utf-8');
      });

      const timer = setTimeout(() => {
        try { py.kill(); } catch (_) {}
        resolve({ code: -1, output: out + '\n❌ Quá thời gian cài đặt thư viện (Timeout > 180s)' });
      }, 180000);

      py.on('close', (code) => {
        clearTimeout(timer);
        resolve({ code, output: out });
      });

      py.on('error', (err) => {
        clearTimeout(timer);
        resolve({ code: -1, output: out + `\n❌ Lỗi tiến trình: ${err.message}` });
      });
    });
  };

  // Attempt 1: Standard install with prefer-binary
  let result = await runPip();

  // If failed due to build/compilation issues from source, attempt 2 with only-binary=:all:
  if (result.code !== 0 && (result.output.includes('Failed building wheel') || result.output.includes('gcc') || result.output.includes('cargo') || result.output.includes('subprocess-exited-with-error'))) {
    result.output += '\n⚠️ Phát hiện lỗi biên dịch mã nguồn; đang tự động thử lại tải bản dựng sẵn (pre-built binary wheel)...\n';
    const retryResult = await runPip(['--only-binary=:all:']);
    if (retryResult.code === 0) {
      result = retryResult;
    } else {
      result.output += retryResult.output;
    }
  }

  if (result.code === 0) {
    const primaryName = pkgTokens[0].split(/[=><~![]/)[0].trim().replace(/-/g, '_');
    let verifyNotice = '';
    let detectedVersion = 'installed';

    // Verify import and retrieve version
    try {
      const vChk = spawn('python3', [
        '-c',
        `import ${primaryName}; print(getattr(${primaryName}, '__version__', 'OK'))`,
      ]);
      let vOut = '';
      await new Promise<void>((vResolve) => {
        const vTimer = setTimeout(() => {
          try { vChk.kill(); } catch (_) {}
          vResolve();
        }, 3000);
        vChk.stdout.on('data', (chunk) => {
          vOut += chunk.toString();
        });
        vChk.on('close', (vCode) => {
          clearTimeout(vTimer);
          if (vCode === 0) {
            const trimmed = vOut.trim();
            if (trimmed && trimmed !== 'OK') {
              detectedVersion = trimmed;
            }
            verifyNotice = `\n✅ [Xác nhận hoạt động]: Đã kiểm tra nạp thử thư viện '${primaryName}' thành công 100%!`;
          }
          vResolve();
        });
        vChk.on('error', () => {
          clearTimeout(vTimer);
          vResolve();
        });
      });
    } catch (_) {}

    // Persist package in workspace registry
    savePersistedPackage(primaryName, detectedVersion);

    res.json({
      success: true,
      message: upgrade ? `Cập nhật thành công ${rawName}` : `Cài đặt thành công ${rawName}`,
      output: result.output + verifyNotice + `\n💾 [Lưu trữ vĩnh viễn]: Thư viện đã được lưu trữ an toàn trong không gian dự án.`,
    });
  } else {
    res.status(500).json({
      success: false,
      error: `Quá trình pip kết thúc với mã lỗi ${result.code}`,
      output: result.output,
    });
  }
});

// REST endpoint: Uninstall Python package with workspace cleanup
app.post('/api/python/packages/uninstall', (req, res) => {
  const { name } = req.body;
  if (!name || typeof name !== 'string') {
    return res.status(400).json({ success: false, error: 'Thiếu tên thư viện' });
  }

  const cleanName = name.trim();
  if (!/^[a-zA-Z0-9_\-\.]+$/.test(cleanName)) {
    return res.status(400).json({ success: false, error: 'Tên thư viện không hợp lệ' });
  }

  // Protect system critical packages
  if (['pip', 'setuptools', 'wheel'].includes(cleanName.toLowerCase())) {
    return res.status(400).json({ success: false, error: 'Không thể gỡ bỏ công cụ cốt lõi của hệ thống (pip/setuptools/wheel)' });
  }

  // 1. Remove from persistent packages directory
  try {
    if (fs.existsSync(PYDROID_PACKAGES_DIR)) {
      const targetLower = cleanName.toLowerCase().replace(/-/g, '_');
      const files = fs.readdirSync(PYDROID_PACKAGES_DIR);
      for (const item of files) {
        const itemLower = item.toLowerCase().replace(/-/g, '_');
        if (
          itemLower === targetLower ||
          itemLower.startsWith(targetLower + '-') ||
          itemLower.startsWith(targetLower + '.')
        ) {
          const itemPath = path.join(PYDROID_PACKAGES_DIR, item);
          fs.rmSync(itemPath, { recursive: true, force: true });
        }
      }
    }
  } catch (e) {
    console.log('Notice deleting package files from .pydroid_packages:', e);
  }

  // 2. Remove from registry
  removePersistedPackage(cleanName);

  // 3. Uninstall from system python if present
  const py = spawn('python3', ['-m', 'pip', 'uninstall', '-y', cleanName, '--break-system-packages']);
  let output = '';

  py.stdout.on('data', (chunk) => {
    output += chunk.toString('utf-8');
  });
  py.stderr.on('data', (chunk) => {
    output += chunk.toString('utf-8');
  });

  py.on('close', (code) => {
    res.json({
      success: true,
      message: `Đã gỡ bỏ thư viện ${cleanName}`,
      output: output || `Đã gỡ bỏ ${cleanName} và dọn dẹp bộ nhớ lưu trữ thành công.`,
    });
  });

  py.on('error', (err) => {
    res.json({
      success: true,
      message: `Đã gỡ bỏ thư viện ${cleanName} khỏi không gian lưu trữ`,
      output: `Dọn dẹp thư viện ${cleanName} thành công.`,
    });
  });
});

// Curated list of popular libraries for instant search & discovery in Pydroid 3
const POPULAR_PYTHON_PACKAGES = [
  { name: 'numpy', summary: 'Mảng số học đa chiều & tính toán khoa học tối ưu' },
  { name: 'pandas', summary: 'Phân tích, xử lý dữ liệu và bảng DataFrame chuyên sâu' },
  { name: 'matplotlib', summary: 'Vẽ đồ thị, biểu đồ và trực quan hóa dữ liệu 2D/3D' },
  { name: 'requests', summary: 'Gửi yêu cầu HTTP/HTTPS mạng dễ dàng cho con người' },
  { name: 'scipy', summary: 'Thuật toán khoa học và kỹ thuật nâng cao' },
  { name: 'sympy', summary: 'Đại số ký hiệu, giải phương trình và toán học giải tích' },
  { name: 'pillow', summary: 'Xử lý, chỉnh sửa và xuất hình ảnh đồ họa (PIL Fork)' },
  { name: 'pygame', summary: 'Thư viện lập trình phát triển game 2D Python' },
  { name: 'pyfiglet', summary: 'Tạo chữ nghệ thuật ASCII Banner FIGlet lớn trong Terminal' },
  { name: 'beautifulsoup4', summary: 'Bóc tách và trích xuất dữ liệu từ HTML và XML' },
  { name: 'flask', summary: 'Khung ứng dụng Web micro framework nhẹ và mạnh mẽ' },
  { name: 'scikit-learn', summary: 'Học máy (Machine Learning) và khai phá dữ liệu' },
  { name: 'seaborn', summary: 'Trực quan hóa thống kê dựa trên Matplotlib' },
  { name: 'openpyxl', summary: 'Đọc và ghi tệp bảng tính Excel (.xlsx)' },
  { name: 'rich', summary: 'Định dạng màu sắc, bảng và thanh tiến trình trong Terminal' },
  { name: 'colorama', summary: 'Văn bản màu sắc ANSI cho giao diện dòng lệnh' },
  { name: 'tqdm', summary: 'Thanh tiến trình (Progress Bar) thông minh nhanh gọn' },
  { name: 'pydantic', summary: 'Xác thực cấu trúc dữ liệu và cài đặt sử dụng Type Hints' },
  { name: 'httpx', summary: 'HTTP client thế hệ mới với hỗ trợ bất đồng bộ (async)' },
  { name: 'qrcode', summary: 'Tạo mã QR code hình ảnh tiêu chuẩn nhanh chóng' },
  { name: 'lxml', summary: 'Xử lý XML và HTML siêu tốc bằng libxml2' },
];

// REST endpoint: Search packages on PyPI and popular catalog
app.get('/api/python/packages/search', async (req, res) => {
  const query = String(req.query.q || '').trim().toLowerCase();
  if (!query) {
    return res.json({ packages: POPULAR_PYTHON_PACKAGES.slice(0, 10) });
  }

  // Filter local popular packages
  const localMatches = POPULAR_PYTHON_PACKAGES.filter(
    (p) => p.name.toLowerCase().includes(query) || p.summary.toLowerCase().includes(query)
  );

  // If exact query matches or user types custom name, try PyPI API
  let pypiPackage: any = null;
  try {
    const fetchRes = await fetch(`https://pypi.org/pypi/${encodeURIComponent(query)}/json`, {
      signal: AbortSignal.timeout(3000),
    });
    if (fetchRes.ok) {
      const data = await fetchRes.json();
      if (data && data.info) {
        pypiPackage = {
          name: data.info.name,
          summary: data.info.summary || 'Thư viện Python trên PyPI',
          version: data.info.version,
        };
      }
    }
  } catch (e) {
    // ignore network errors
  }

  const results: any[] = [];
  if (pypiPackage && !localMatches.some((m) => m.name.toLowerCase() === pypiPackage.name.toLowerCase())) {
    results.push(pypiPackage);
  }
  results.push(...localMatches);

  res.json({ packages: results.slice(0, 15) });
});

// Helper to post-process and ensure 100% Vietnamese variable names in lessons
function ensureVietnameseLessonQuality(lesson: any) {
  let { starterCode = '', solutionCode = '' } = lesson;

  // Replace common English variable leaks with clear Vietnamese names
  const varMap: Record<string, string> = {
    '\\btotal\\b': 'tong_so',
    '\\bresult\\b': 'ket_qua',
    '\\bdata\\b': 'du_lieu',
    '\\bitems\\b': 'danh_sach_muc',
    '\\bitem\\b': 'phan_tu',
    '\\bcount\\b': 'so_luong',
    '\\btemp\\b': 'bien_tam',
    '\\bnumbers\\b': 'danh_sach_so',
    '\\buser_num\\b': 'so_nguoi_chon',
    '\\bchosen\\b': 'so_da_chon',
    '\\bdie1\\b': 'xuc_xac_1',
    '\\bdie2\\b': 'xuc_xac_2',
    '\\bmy_func\\b': 'ham_xu_ly',
    '\\bprocess_data\\b': 'xu_ly_du_lieu',
    '\\bfiltered\\b': 'danh_sach_loc',
    '\\boutput\\b': 'dau_ra',
    '\\binput_val\\b': 'gia_tri_nhap',
    '\\barr\\b': 'mang_so',
    '\\blst\\b': 'danh_sach',
  };

  for (const [pattern, replacement] of Object.entries(varMap)) {
    const re = new RegExp(pattern, 'g');
    starterCode = starterCode.replace(re, replacement);
    solutionCode = solutionCode.replace(re, replacement);
  }

  const rawLvl = String(lesson.level || '').toLowerCase().trim();
  const normalizedLevel = (rawLvl.includes('nâng') || rawLvl.includes('nang') || rawLvl.includes('adv') || rawLvl.includes('hard') || rawLvl.includes('3'))
    ? 'advanced'
    : (rawLvl.includes('trung') || rawLvl.includes('inter') || rawLvl.includes('vừa') || rawLvl.includes('2'))
    ? 'intermediate'
    : 'basic';

  const safeId = lesson.id && typeof lesson.id === 'string' && lesson.id.startsWith('lesson_') && !lesson.id.includes('undefined')
    ? `${lesson.id}_${Date.now().toString(36)}`
    : `lesson_ai_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

  return {
    ...lesson,
    id: safeId,
    title: String(lesson.title || 'Bài tập thực hành Python mới').trim(),
    level: normalizedLevel,
    description: String(lesson.description || '').trim(),
    starterCode: String(starterCode || '').trim(),
    solutionCode: String(solutionCode || '').trim(),
    explanation: String(lesson.explanation || 'Thuật toán được tối ưu chuẩn PEP 8 với 100% tên biến tiếng Việt.').trim(),
    sampleInput: lesson.sampleInput || '',
    sampleOutput: lesson.sampleOutput || '',
    completed: false,
  };
}

// Helper to generate smart fallback lessons if Gemini API is under high demand (503)
// Rich Dynamic Fallback Lesson Generator (100% Vietnamese variables, guarantees unique titles)
function getFallbackLessons(topic: string, levelStr: string, existingTitles: string[] = []) {
  const normTopic = topic.toLowerCase().trim();
  const level = (levelStr === 'nâng cao' ? 'advanced' : levelStr === 'trung cấp' ? 'intermediate' : 'basic') as 'basic' | 'intermediate' | 'advanced';
  const ts = Date.now().toString(36);
  const titlesSet = new Set(existingTitles.map((t) => t.toLowerCase().trim()));

  const makeUniqueTitle = (baseTitle: string) => {
    let t = baseTitle;
    let cnt = 1;
    while (titlesSet.has(t.toLowerCase().trim())) {
      cnt++;
      t = `${baseTitle} (Mục ${cnt})`;
    }
    titlesSet.add(t.toLowerCase().trim());
    return t;
  };

  const pool: any[] = [];

  // 1. Topic: Vòng lặp / Loop
  if (normTopic.includes('vòng lặp') || normTopic.includes('loop') || normTopic.includes('for') || normTopic.includes('while')) {
    pool.push({
      id: `lesson_cuu_chuong_${ts}`,
      title: makeUniqueTitle(`Thực hành: Bảng cửu chương tuần hoàn (${topic})`),
      level,
      description: 'Nhập số nguyên dương n (từ 1 đến 9). Sử dụng vòng lặp for để in ra bảng cửu chương tương ứng với định dạng n x i = ket_qua.',
      starterCode: `# Nhập số cần in bảng nhân\nso_nhan = int(input("Nhập số bảng cửu chương (1-9): "))\n\n# TODO: Dùng vòng lặp for để in bảng nhân từ 1 đến 10\nfor chi_so in range(1, 11):\n    tich_so = so_nhan * chi_so\n    print(f"{so_nhan} x {chi_so} = {tich_so}")\n`,
      solutionCode: `def in_bang_cuu_chuong(con_so: int) -> None:\n    for thu_tu in range(1, 11):\n        ket_qua_nhan = con_so * thu_tu\n        print(f"{con_so} x {thu_tu} = {ket_qua_nhan}")\n\nif __name__ == "__main__":\n    so_can_in = int(input("Bảng cửu chương số: "))\n    in_bang_cuu_chuong(so_can_in)\n`,
      explanation: 'Vòng lặp for kết hợp với hàm range(1, 11) giúp lặp chính xác 10 lần từ 1 đến 10 theo đúng chuẩn mực PEP 8.',
      sampleInput: '7\n',
      sampleOutput: '7 x 1 = 7\n7 x 2 = 14\n...\n7 x 10 = 70\n',
    });
    pool.push({
      id: `lesson_tong_le_${ts}`,
      title: makeUniqueTitle(`Thực hành: Tính tổng các số lẻ liên tiếp (${topic})`),
      level,
      description: 'Nhập vào số nguyên dương n. Sử dụng vòng lặp tính tổng tất cả các số lẻ từ 1 đến n và in ra màn hình.',
      starterCode: `gioi_han_n = int(input("Nhập số n: "))\n\n# TODO: Tính tổng các số lẻ từ 1 đến n\ntong_so_le = 0\nfor so_hien_tai in range(1, gioi_han_n + 1):\n    if so_hien_tai % 2 != 0:\n        tong_so_le += so_hien_tai\n\nprint(f"Tổng các số lẻ từ 1 đến {gioi_han_n} là: {tong_so_le}")\n`,
      solutionCode: `def tinh_tong_so_le(gioi_han: int) -> int:\n    tong_tich_luy = sum(so for so in range(1, gioi_han + 1) if so % 2 != 0)\n    return tong_tich_luy\n\nif __name__ == "__main__":\n    so_n = int(input("Nhập n: "))\n    dap_an = tinh_tong_so_le(so_n)\n    print(f"Tổng số lẻ: {dap_an}")\n`,
      explanation: 'Toán tử chia lấy dư % 2 != 0 giúp kiểm tra tính chẵn lẻ của số nguyên nhanh chóng.',
      sampleInput: '9\n',
      sampleOutput: 'Tổng các số lẻ từ 1 đến 9 là: 25\n',
    });
  }

  // 2. Topic: Chuỗi / Xử lý văn bản
  else if (normTopic.includes('chuỗi') || normTopic.includes('string') || normTopic.includes('văn bản') || normTopic.includes('từ')) {
    pool.push({
      id: `lesson_dem_tu_${ts}`,
      title: makeUniqueTitle(`Thực hành: Đếm từ & chuẩn hoá họ tên (${topic})`),
      level,
      description: 'Nhập họ và tên người dùng có khoảng trắng thừa. Viết chương trình chuẩn hóa chuỗi (bỏ khoảng trắng thừa, viết hoa chữ cái đầu mỗi từ) và đếm tổng số từ.',
      starterCode: `ho_ten_tho = input("Nhập họ tên: ")\n\n# TODO: Chuẩn hóa họ tên\ndanh_sach_tu = ho_ten_tho.strip().split()\nho_ten_chuan = " ".join(tu.capitalize() for tu in danh_sach_tu)\nso_luong_tu = len(danh_sach_tu)\n\nprint(f"Họ tên chuẩn: {ho_ten_chuan}")\nprint(f"Số lượng từ: {so_luong_tu}")\n`,
      solutionCode: `def chuan_hoa_ho_ten(chuoi_nhap: str) -> tuple[str, int]:\n    cac_tu = chuoi_nhap.strip().split()\n    ten_chuan = " ".join(tung_tu.capitalize() for tung_tu in cac_tu)\n    return ten_chuan, len(cac_tu)\n\nif __name__ == "__main__":\n    chuoi_goc = input("Họ tên: ")\n    ten_dep, so_tu = chuan_hoa_ho_ten(chuoi_goc)\n    print(f"Tên: {ten_dep} | Số từ: {so_tu}")\n`,
      explanation: 'Phương thức split() tự động tách chuỗi theo khoảng trắng bất kỳ, kết hợp capitalize() để viết hoa chữ cái đầu.',
      sampleInput: '   nguyen   van   an   \n',
      sampleOutput: 'Họ tên chuẩn: Nguyen Van An\nSố lượng từ: 3\n',
    });
    pool.push({
      id: `lesson_nguyen_am_${ts}`,
      title: makeUniqueTitle(`Thực hành: Thống kê nguyên âm trong câu (${topic})`),
      level,
      description: 'Nhập một câu văn bản tiếng Việt không dấu. Đếm số lượng các nguyên âm (a, e, i, o, u) xuất hiện trong câu.',
      starterCode: `cau_van_ban = input("Nhập văn bản: ").lower()\nnguyen_am = "aeiou"\n\n# TODO: Đếm số nguyên âm\nso_nguyen_am = sum(1 for ky_tu in cau_van_ban if ky_tu in nguyen_am)\nprint(f"Số lượng nguyên âm: {so_nguyen_am}")\n`,
      solutionCode: `def dem_so_nguyen_am(van_ban: str) -> int:\n    tap_nguyen_am = set("aeiou")\n    return sum(1 for chu in van_ban.lower() if chu in tap_nguyen_am)\n\nif __name__ == "__main__":\n    doan_van = input("Văn bản: ")\n    print(f"Tổng nguyên âm: {dem_so_nguyen_am(doan_van)}")\n`,
      explanation: 'Sử dụng cấu trúc set() tăng tốc độ tra cứu phần tử với độ phức tạp O(1).',
      sampleInput: 'lap trinh python tren pydroid\n',
      sampleOutput: 'Số lượng nguyên âm: 7\n',
    });
  }

  // 3. Topic: Game / Trò chơi / Xúc xắc
  else if (normTopic.includes('game') || normTopic.includes('trò chơi') || normTopic.includes('xúc xắc') || normTopic.includes('đoán')) {
    pool.push({
      id: `lesson_xuc_xac_${ts}`,
      title: makeUniqueTitle(`Mini-Game: Đổ xúc xắc tính điểm thưởng (${topic})`),
      level,
      description: 'Mô phỏng gieo 2 viên xúc xắc 6 mặt (1-6). Nếu tổng điểm >= 10 hoặc 2 viên xúc xắc có cùng số điểm (xúc xắc đôi), người chơi thắng lớn!',
      starterCode: `import random\n\n# TODO: Gieo 2 viên xúc xắc\nxuc_xac_1 = random.randint(1, 6)\nxuc_xac_2 = random.randint(1, 6)\ntong_diem = xuc_xac_1 + xuc_xac_2\n\nprint(f"Viên 1: {xuc_xac_1} | Viên 2: {xuc_xac_2} -> Tổng: {tong_diem}")\nif xuc_xac_1 == xuc_xac_2:\n    print("🎉 BẠN ĐỔ ĐƯỢC XÚC XẮC ĐÔI! Thắng đậm!")\nelif tong_diem >= 10:\n    print("🏆 Xuất sắc! Điểm cao chiến thắng!")\nelse:\n    print("Chúc bạn may mắn lần sau!")\n`,
      solutionCode: `import random\n\ndef gieo_xuc_xac() -> tuple[int, int, int, str]:\n    vien_1 = random.randint(1, 6)\n    vien_2 = random.randint(1, 6)\n    tong = vien_1 + vien_2\n    if vien_1 == vien_2:\n        thong_bao = "Xúc xắc đôi thắng lớn!"\n    elif tong >= 10:\n        thong_bao = "Điểm cao thắng cuộc!"\n    else:\n        thong_bao = "Lượt chơi bình thường."\n    return vien_1, vien_2, tong, thong_bao\n\nif __name__ == "__main__":\n    v1, v2, t, tb = gieo_xuc_xac()\n    print(f"Lượt gieo: [{v1}] và [{v2}] (Tổng: {t}) -> {tb}")\n`,
      explanation: 'Module random cung cấp hàm randint() tạo số ngẫu nhiên mô phỏng trò chơi xúc xắc sinh động.',
      sampleOutput: 'Lượt gieo: [5] và [5] (Tổng: 10) -> Xúc xắc đôi thắng lớn!\n',
    });
    pool.push({
      id: `lesson_keo_bua_bao_${ts}`,
      title: makeUniqueTitle(`Mini-Game: Kéo Búa Bao đối đầu máy tính (${topic})`),
      level,
      description: 'Cho người chơi chọn Kéo, Búa hoặc Bao. Máy tính chọn ngẫu nhiên. So sánh kết quả và in ra người chiến thắng.',
      starterCode: `import random\n\ncac_lua_chon = ["kéo", "búa", "bao"]\nnguoi_chon = input("Chọn kéo, búa hoặc bao: ").lower().strip()\nmay_chon = random.choice(cac_lua_chon)\n\nprint(f"Bạn ra: {nguoi_chon} | Máy ra: {may_chon}")\nif nguoi_chon == may_chon:\n    print("Hòa nhau!")\nelif (nguoi_chon == "búa" and may_chon == "kéo") or \\\n     (nguoi_chon == "kéo" and may_chon == "bao") or \\\n     (nguoi_chon == "bao" and may_chon == "búa"):\n    print("🎉 Bạn đã chiến thắng!")\nelse:\n    print("Máy tính đã thắng!")\n`,
      solutionCode: `import random\n\ndef dau_keo_bua_bao(lua_chon_nguoi: str) -> str:\n    cac_nuoc_di = ["kéo", "búa", "bao"]\n    nuoc_di_may = random.choice(cac_nuoc_di)\n    print(f"Người: {lua_chon_nguoi} vs Máy: {nuoc_di_may}")\n    if lua_chon_nguoi == nuoc_di_may:\n        return "Hòa!"\n    thang = [("búa", "kéo"), ("kéo", "bao"), ("bao", "búa")]\n    if (lua_chon_nguoi, nuoc_di_may) in thang:\n        return "Người chơi thắng!"\n    return "Máy tính thắng!"\n\nif __name__ == "__main__":\n    nuoc_nguoi = input("Chọn: ")\n    print(dau_keo_bua_bao(nuoc_nguoi))\n`,
      explanation: 'Sử dụng danh sách các cặp bộ thắng trong tuple giúp kiểm tra điều kiện chiến thắng ngắn gọn.',
      sampleInput: 'búa\n',
      sampleOutput: 'Người: búa vs Máy: kéo\nNgười chơi thắng!\n',
    });
  }

  // 4. Default / Real-World Applications
  else {
    pool.push({
      id: `lesson_tra_sua_${ts}`,
      title: makeUniqueTitle(`Thực hành: Tính tiền hoá đơn Trà sữa (${topic})`),
      level,
      description: 'Viết chương trình tính tiền đặt hàng trà sữa. Nhập số lượng ly, đơn giá từng ly và phần trăm giảm giá khuyến mãi (nếu có). In ra tổng số tiền phải thanh toán kèm hóa đơn chi tiết.',
      starterCode: `# Nhập thông tin đơn hàng trà sữa\nso_luong_ly = int(input("Nhập số lượng ly trà sữa: "))\ndon_gia_ly = int(input("Nhập đơn vị giá mỗi ly (VNĐ): "))\nphan_tram_giam = float(input("Nhập % giảm giá (vd: 10 cho 10%): "))\n\n# TODO: Tính tổng tiền trước giảm và sau giảm\ntong_tien_goc = so_luong_ly * don_gia_ly\ntien_duoc_giam = tong_tien_goc * (phan_tram_giam / 100)\ntong_thanh_toan = tong_tien_goc - tien_duoc_giam\n\nprint(f"Tổng tiền gốc: {tong_tien_goc:,.0f} VNĐ")\nprint(f"Số tiền giảm: {tien_duoc_giam:,.0f} VNĐ")\nprint(f"Số tiền cần trả: {tong_thanh_toan:,.0f} VNĐ")\n`,
      solutionCode: `def tinh_tien_hoa_don(so_luong: int, don_gia: int, giam_gia_phan_tram: float) -> tuple[float, float, float]:\n    tong_tien_chua_giam = so_luong * don_gia\n    so_tien_giam = tong_tien_chua_giam * (giam_gia_phan_tram / 100.0)\n    tong_so_tien_phai_tra = tong_tien_chua_giam - so_tien_giam\n    return tong_tien_chua_giam, so_tien_giam, tong_so_tien_phai_tra\n\nif __name__ == "__main__":\n    so_ly = int(input("Số ly: "))\n    gia_moi_ly = int(input("Đơn giá: "))\n    muc_giam = float(input("Phần trăm giảm: "))\n    \n    tien_goc, tien_giam, thanh_toan = tinh_tien_hoa_don(so_ly, gia_moi_ly, muc_giam)\n    print(f"Hoá đơn: Gốc {tien_goc:,.0f}đ - Giảm {tien_giam:,.0f}đ = Thanh toán: {thanh_toan:,.0f}đ")\n`,
      explanation: 'Bài toán rèn luyện kỹ năng tính toán số học, định dạng số có dấu phân cách hàng nghìn (:,.0f) và đặt tên biến 100% tiếng Việt chuẩn snake_case.',
      sampleInput: '3\n35000\n10\n',
      sampleOutput: 'Hoá đơn: Gốc 105,000đ - Giảm 10,500đ = Thanh toán: 94,500đ\n',
    });
    pool.push({
      id: `lesson_chi_tieu_${ts}`,
      title: makeUniqueTitle(`Thực hành: Quản lý chi tiêu sinh hoạt (${topic})`),
      level,
      description: 'Cho danh sách các khoản chi tiêu trong tuần của sinh viên. Viết hàm tính tổng chi tiêu, tìm khoản chi tiêu lớn nhất và tính mức chi tiêu trung bình mỗi ngày.',
      starterCode: `# Danh sách các khoản chi tiêu trong tuần\ndanh_sach_chi_tieu = [45000, 120000, 60000, 250000, 80000, 30000, 95000]\n\n# TODO: Tính tổng chi tiêu và chi tiêu lớn nhất\ntong_so_tien_chi = sum(danh_sach_chi_tieu)\nkhoan_chi_lon_nhat = max(danh_sach_chi_tieu)\nchi_tieu_trung_binh = tong_so_tien_chi / len(danh_sach_chi_tieu)\n\nprint(f"Tổng chi trong tuần: {tong_so_tien_chi:,.0f} VNĐ")\nprint(f"Khoản chi nhiều nhất: {khoan_chi_lon_nhat:,.0f} VNĐ")\nprint(f"Trung bình mỗi ngày: {chi_tieu_trung_binh:,.0f} VNĐ")\n`,
      solutionCode: `def phan_tich_chi_tieu(cac_khoan_chi: list[int]) -> dict:\n    tong_chi = sum(cac_khoan_chi)\n    chi_cao_nhat = max(cac_khoan_chi) if cac_khoan_chi else 0\n    trung_binh_ngay = tong_chi / len(cac_khoan_chi) if cac_khoan_chi else 0.0\n    return {\n        "tong_tien": tong_chi,\n        "cao_nhat": chi_cao_nhat,\n        "trung_binh": trung_binh_ngay\n    }\n\nif __name__ == "__main__":\n    so_lieu_chi = [45000, 120000, 60000, 250000, 80000, 30000, 95000]\n    ket_qua_thong_ke = phan_tich_chi_tieu(so_lieu_chi)\n    print(f"Tổng chi: {ket_qua_thong_ke['tong_tien']:,}đ | Cao nhất: {ket_qua_thong_ke['cao_nhat']:,}đ")\n`,
      explanation: 'Sử dụng các hàm có sẵn sum(), max(), len() kết hợp với kiểu dữ liệu từ điển (dict) giúp cấu trúc dữ liệu tường minh, chuẩn mực.',
      sampleOutput: 'Tổng chi: 680,000đ | Cao nhất: 250,000đ\n',
    });
    pool.push({
      id: `lesson_diem_thi_${ts}`,
      title: makeUniqueTitle(`Thực hành: Thống kê & Xếp loại điểm thi (${topic})`),
      level,
      description: 'Nhập danh sách điểm thi của các môn học. Tính điểm trung bình môn, đếm số môn đạt loại Giỏi (từ 8.0 trở lên) và in kết luận xếp loại chung.',
      starterCode: `# Danh sách điểm các môn\nbang_diem_hoc_ky = [8.5, 7.0, 9.2, 6.5, 8.8, 9.0]\n\n# TODO: Tính điểm trung bình và đếm môn Giỏi (>= 8.0)\ndiem_trung_binh = sum(bang_diem_hoc_ky) / len(bang_diem_hoc_ky)\nso_mon_gioi = sum(1 for diem in bang_diem_hoc_ky if diem >= 8.0)\n\nprint(f"Điểm trung bình học kỳ: {diem_trung_binh:.2f}")\nprint(f"Số môn đạt loại Giỏi: {so_mon_gioi}")\n`,
      solutionCode: `def xep_loai_hoc_tap(danh_sach_diem: list[float]) -> tuple[float, str]:\n    diem_trung_binh_chung = sum(danh_sach_diem) / len(danh_sach_diem)\n    if diem_trung_binh_chung >= 8.0:\n        danh_hieu = "Học sinh Giỏi"\n    elif diem_trung_binh_chung >= 6.5:\n        danh_hieu = "Học sinh Khá"\n    else:\n        danh_hieu = "Học sinh Trung bình"\n    return diem_trung_binh_chung, danh_hieu\n\nif __name__ == "__main__":\n    diem_cac_mon = [8.5, 7.0, 9.2, 6.5, 8.8, 9.0]\n    diem_tb, danh_hieu = xep_loai_hoc_tap(diem_cac_mon)\n    print(f"Điểm TB: {diem_tb:.2f} -> Danh hiệu: {danh_hieu}")\n`,
      explanation: 'Vận dụng rẽ nhánh điều kiện if-elif-else kết hợp tính toán số thực (float) với độ chính xác cao.',
      sampleOutput: 'Điểm TB: 8.17 -> Danh hiệu: Học sinh Giỏi\n',
    });
    pool.push({
      id: `lesson_cuoc_xe_${ts}`,
      title: makeUniqueTitle(`Ứng dụng: Tính giá cước xe công nghệ (${topic})`),
      level,
      description: 'Xây dựng thuật toán tính tiền chuyến xe công nghệ theo quãng đường đi (km): 2 km đầu giá 20,000đ, từ km thứ 3 đến km thứ 10 giá 8,500đ/km, từ km thứ 11 trở đi giá 7,000đ/km.',
      starterCode: `so_km_di_chuyen = float(input("Nhập số km chuyến xe: "))\n\n# TODO: Tính tổng cước phí theo từng chặng\ntong_cuoc_phi = 0.0\nif so_km_di_chuyen <= 2:\n    tong_cuoc_phi = 20000.0\nelif so_km_di_chuyen <= 10:\n    tong_cuoc_phi = 20000.0 + (so_km_di_chuyen - 2) * 8500.0\nelse:\n    tong_cuoc_phi = 20000.0 + 8 * 8500.0 + (so_km_di_chuyen - 10) * 7000.0\n\nprint(f"Tổng tiền cước: {tong_cuoc_phi:,.0f} VNĐ")\n`,
      solutionCode: `def tinh_cuoc_chuyen_xe(quang_duong_km: float) -> float:\n    if quang_duong_km <= 2.0:\n        return 20000.0\n    if quang_duong_km <= 10.0:\n        return 20000.0 + (quang_duong_km - 2.0) * 8500.0\n    return 20000.0 + (8.0 * 8500.0) + (quang_duong_km - 10.0) * 7000.0\n\nif __name__ == "__main__":\n    so_km = float(input("Nhập quãng đường (km): "))\n    tien_xe = tinh_cuoc_chuyen_xe(so_km)\n    print(f"Quãng đường {so_km} km -> Giá cước: {tien_xe:,.0f} VNĐ")\n`,
      explanation: 'Bài toán tính cước luỹ tiến đa bậc là dạng bài tập kinh điển trong khoa học máy tính, rèn luyện cấu trúc rẽ nhánh chính xác.',
      sampleInput: '15\n',
      sampleOutput: 'Quãng đường 15.0 km -> Giá cước: 123,000 VNĐ\n',
    });
  }

  return pool.slice(0, 2).map(ensureVietnameseLessonQuality);
}

// Timeout helper for Gemini calls with generous allowance for complex reasoning & JSON generation
function withTimeout<T>(promise: Promise<T>, ms = 35000, timeoutMessage = 'Gemini API timeout'): Promise<T> {
  let timer: NodeJS.Timeout | null = null;
  const timeoutPromise = new Promise<T>((_, reject) => {
    timer = setTimeout(() => reject(new Error(timeoutMessage)), ms);
  });
  return Promise.race([promise, timeoutPromise]).finally(() => {
    if (timer) clearTimeout(timer);
  });
}

// Multi-model fallback chain using active Gemini models from gemini-api skill
const CANDIDATE_MODELS = [
  'gemini-4-hydrogen',
  'gemini-3.1-flash-lite',
];

function supportsThinkingConfig(modelName: string): boolean {
  return modelName.includes('gemini-4');
}

function isAuthOrPermissionError(err: any): boolean {
  const msg = String(err?.message || err || '').toLowerCase();
  const status = (err?.status as number) || (err?.statusCode as number);
  return (
    status === 401 ||
    status === 403 ||
    msg.includes('api_key_invalid') ||
    msg.includes('api key not valid') ||
    msg.includes('api key expired') ||
    msg.includes('permission_denied') ||
    msg.includes('unauthenticated')
  );
}

function extractFriendlyGeminiError(err: any): { friendly: string; raw: string; code?: number } {
  const raw = String(err?.message || err || '');
  let code: number | undefined = (err?.status as number) || (err?.statusCode as number);

  try {
    const jsonMatch = raw.match(/\{[\s\S]*"error"[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      if (parsed?.error) {
        if (parsed.error.code) code = parsed.error.code;
        const msg = parsed.error.message || '';
        const details = parsed.error.details || [];
        const isInvalidKey = details.some((d: any) => d.reason === 'API_KEY_INVALID') || msg.includes('API key not valid');
        if (isInvalidKey) {
          return {
            friendly: 'Máy chủ Gemini AI chưa có GEMINI_API_KEY hợp lệ từ bảng Settings > Secrets của dự án Google AI Studio.',
            raw,
            code: 400,
          };
        }
        if (msg.includes('Quota exceeded') || msg.includes('RESOURCE_EXHAUSTED') || code === 429) {
          return {
            friendly: 'Dịch vụ Gemini API đang vượt hạn mức sử dụng tạm thời (Quota Exceeded). Vui lòng thử lại sau ít phút.',
            raw,
            code: 429,
          };
        }
        if (msg.includes('not found') || code === 404) {
          return {
            friendly: `Mô hình AI chưa được hỗ trợ trên Project này: ${msg}`,
            raw,
            code: 404,
          };
        }
        if (msg) {
          return { friendly: `Lỗi từ Google: ${msg}`, raw, code };
        }
      }
    }
  } catch (_) {}

  const lower = raw.toLowerCase();
  if (lower.includes('api_key_invalid') || lower.includes('api key not valid') || lower.includes('unauthenticated')) {
    return {
      friendly: 'Máy chủ Gemini AI chưa có GEMINI_API_KEY hợp lệ từ bảng Settings > Secrets của dự án Google AI Studio.',
      raw,
      code: 401,
    };
  }
  if (lower.includes('quota') || lower.includes('resource_exhausted') || lower.includes('rate limit') || lower.includes('429')) {
    return {
      friendly: 'Dịch vụ Gemini API đang vượt hạn mức sử dụng miễn phí (Quota Limit). Vui lòng thử lại sau ít phút.',
      raw,
      code: 429,
    };
  }
  if (lower.includes('permission_denied') || lower.includes('403')) {
    return {
      friendly: 'Dịch vụ Gemini API bị từ chối quyền truy cập (Permission Denied). Hãy kiểm tra GEMINI_API_KEY và Generative Language API trong dự án.',
      raw,
      code: 403,
    };
  }
  if (lower.includes('timeout') || lower.includes('etimedout') || lower.includes('deadline exceeded')) {
    return {
      friendly: 'Quá thời gian kết nối tới Google Gemini (Timeout). Vui lòng kiểm tra lại kết nối mạng.',
      raw,
      code: 504,
    };
  }
  if (lower.includes('fetch failed') || lower.includes('network')) {
    return {
      friendly: 'Không thể kết nối đến máy chủ Google Gemini. Vui lòng kiểm tra kết nối mạng Internet của bạn.',
      raw,
      code: 0,
    };
  }

  return {
    friendly: raw || 'Không nhận được phản hồi từ mô hình',
    raw,
    code,
  };
}

function getAiClient(_req?: express.Request): {
  aiClient: GoogleGenAI;
  hasKey: boolean;
  isCustom: boolean;
  hasServerKey: boolean;
} {
  const { client, key } = getActiveAiInstance();
  const hasServerKey = isValidGeminiKeyFormat(key);
  return {
    aiClient: client,
    hasKey: hasServerKey,
    isCustom: false,
    hasServerKey,
  };
}

function getAiClientForRequest(req?: express.Request): {
  aiClient: GoogleGenAI;
  hasKey: boolean;
  isCustom: boolean;
  hasServerKey: boolean;
} {
  return getAiClient(req);
}

function classifyServerAiError(err: any): {
  failureType: 'INVALID_KEY' | 'NETWORK_TIMEOUT' | 'SERVER_REJECTION' | 'UNKNOWN';
  reason: string;
  remediation: string;
} {
  const msg = String(err?.message || err || '');
  const lower = msg.toLowerCase();
  const status = (err?.status as number) || (err?.statusCode as number);

  if (
    status === 401 ||
    lower.includes('api key not valid') ||
    lower.includes('api_key_invalid') ||
    lower.includes('unauthenticated') ||
    lower.includes('invalid api key') ||
    lower.includes('api key expired') ||
    lower.includes('key is missing')
  ) {
    return {
      failureType: 'INVALID_KEY',
      reason: 'GEMINI_API_KEY của máy chủ chưa được thiết lập đúng hoặc đã bị thu hồi.',
      remediation: 'Mở bảng Settings > Secrets của dự án Google AI Studio để chọn hoặc cập nhật GEMINI_API_KEY hợp lệ.',
    };
  }

  if (
    status === 408 ||
    status === 504 ||
    lower.includes('timeout') ||
    lower.includes('timed out') ||
    lower.includes('etimedout') ||
    lower.includes('esockettimedout') ||
    lower.includes('abort') ||
    lower.includes('deadline exceeded')
  ) {
    return {
      failureType: 'NETWORK_TIMEOUT',
      reason: 'Quá thời gian chờ phản hồi từ Google Gemini API (Network Timeout).',
      remediation: 'Kiểm tra kết nối mạng và độ trễ upstream. Hệ thống sẽ tự động thử lại với các mô hình dự phòng.',
    };
  }

  if (
    (status && status >= 400 && status !== 401) ||
    lower.includes('resource_exhausted') ||
    lower.includes('quota') ||
    lower.includes('rate limit') ||
    lower.includes('permission_denied') ||
    lower.includes('500') ||
    lower.includes('502') ||
    lower.includes('503') ||
    lower.includes('429') ||
    lower.includes('403')
  ) {
    return {
      failureType: 'SERVER_REJECTION',
      reason: `Máy chủ Google Gemini từ chối yêu cầu (${status ? `HTTP ${status}` : 'Server Error'}).`,
      remediation: 'Nếu là lỗi 429 (hết hạn mức), hãy thử lại sau ít phút hoặc dùng API Key thuộc Project khác.',
    };
  }

  return {
    failureType: 'UNKNOWN',
    reason: `Lỗi phát sinh trong quá trình gọi AI: ${msg}`,
    remediation: 'Kiểm tra chi tiết lỗi bên dưới để xử lý.',
  };
}

function printTerminalAiDiagnostic(diag: {
  timestamp?: string;
  endpoint: string;
  operation?: string;
  failureType: string;
  httpStatus?: number;
  errorMessage: string;
  keyValidation?: any;
  remediation?: string;
  source?: string;
}) {
  const ts = diag.timestamp || new Date().toISOString();
  const sep = '='.repeat(78);
  const colorCyan = '\x1b[36;1m';
  const colorYellow = '\x1b[33;1m';
  const colorReset = '\x1b[0m';

  console.log(`\n${colorCyan}${sep}${colorReset}`);
  console.log(`${colorCyan}[AI Diagnostic Info] (${diag.failureType}): ${diag.endpoint} [${diag.operation || 'AI Operation'}]${colorReset}`);
  console.log(`Timestamp:      ${ts}`);
  console.log(`Classification: ${colorYellow}[${diag.failureType}]${colorReset}`);
  if (diag.httpStatus) {
    console.log(`HTTP Status:    ${diag.httpStatus}`);
  }
  if (diag.keyValidation) {
    console.log(`API Key Info:   Source: ${diag.keyValidation.source || 'N/A'}, Status: ${diag.keyValidation.status || 'N/A'}, Masked: ${diag.keyValidation.maskedKey || 'N/A'}, Length: ${diag.keyValidation.keyLength ?? 'N/A'}`);
    if (diag.keyValidation.reason) {
      console.log(`Key Issue:      ${diag.keyValidation.reason}`);
    }
  }
  const cleanErrorMsg = typeof diag.errorMessage === 'string' && diag.errorMessage.includes('{')
    ? (extractFriendlyGeminiError(diag.errorMessage).friendly || 'Dịch vụ Gemini đang tạm thời gián đoạn')
    : String(diag.errorMessage || '');
  console.log(`Diagnostic:     ${cleanErrorMsg}`);
  if (diag.remediation) {
    console.log(`${colorCyan}Remediation:    ${diag.remediation}${colorReset}`);
  }
  console.log(`${colorCyan}${sep}${colorReset}\n`);
}

async function callWithModelFallback<T>(
  fn: (modelName: string) => Promise<T>
): Promise<T> {
  let lastError: any = null;
  for (const model of CANDIDATE_MODELS) {
    try {
      return await fn(model);
    } catch (err: any) {
      lastError = err;
      if (isAuthOrPermissionError(err)) {
        throw err;
      }
      continue;
    }
  }
  throw lastError;
}

// Intelligent local Python code analyzer for zero-delay offline & fallback explanations
function analyzePythonCodeLocally(code: string) {
  const lines = code ? code.split('\n') : [];
  const imports: string[] = [];
  const functions: string[] = [];
  let hasLoops = false;
  let hasConditionals = false;
  let hasInput = false;
  let hasPrint = false;

  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (line.startsWith('import ') || line.startsWith('from ')) {
      imports.push(line);
    }
    const defMatch = line.match(/^def\s+([a-zA-Z0-9_]+)\s*\(/);
    if (defMatch) {
      functions.push(defMatch[1]);
    }
    if (line.startsWith('for ') || line.startsWith('while ')) {
      hasLoops = true;
    }
    if (line.startsWith('if ') || line.startsWith('elif ') || line.startsWith('else:')) {
      hasConditionals = true;
    }
    if (line.includes('input(')) {
      hasInput = true;
    }
    if (line.includes('print(')) {
      hasPrint = true;
    }
  }

  return {
    linesCount: lines.length,
    imports,
    functions,
    hasLoops,
    hasConditionals,
    hasInput,
    hasPrint,
  };
}

// Local analyzer to detect exact error line, explain cause, and generate cleaner & shorter code
function analyzeAndFixLocally(code: string, errorText: string = ''): string {
  if (!code || !code.trim()) {
    return `🔍 **Phân tích mã nguồn:**\n- Chưa có mã nguồn trong Editor.\n\n⚡ **Mã mẫu chuẩn Python (PEP 8):**\n\`\`\`python\ndef main():\n    print("Hello, Pydroid 3!")\n\nif __name__ == "__main__":\n    main()\n\`\`\``;
  }

  const lines = code.split('\n');
  const fixedLines = [...lines];
  let errorLine = -1;
  let errorLineContent = '';
  let errorCause = '';
  let errorType = '';

  // Parse traceback if present
  if (errorText) {
    const lineMatch = errorText.match(/line (\d+)/i);
    if (lineMatch) {
      const parsedLine = parseInt(lineMatch[1], 10);
      if (parsedLine >= 1 && parsedLine <= lines.length) {
        errorLine = parsedLine;
        errorLineContent = lines[parsedLine - 1] || '';
      }
    }
    const typeMatch = errorText.match(/([A-Za-z]+Error|[A-Za-z]+Exception): (.*)/);
    if (typeMatch) {
      errorType = typeMatch[1];
      errorCause = `Thông báo lỗi từ hệ thống: ${typeMatch[2]}`;
    }
  }

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const trimmed = rawLine.trim();
    const lineNum = i + 1;

    // 1. Missing colon on compound statement
    if (/^(if|elif|else|for|while|def|class|try|except|finally|with)\b/.test(trimmed) && !trimmed.endsWith(':') && !trimmed.includes('#')) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'SyntaxError';
        errorCause = `Thiếu dấu hai chấm ':' ở cuối câu lệnh \`${trimmed.split(' ')[0]}\`.`;
      }
      fixedLines[i] = rawLine + ':';
      continue;
    }

    // 2. Unbalanced parentheses (e.g. print("hello" or (a + b)
    const openParen = (rawLine.match(/\(/g) || []).length;
    const closeParen = (rawLine.match(/\)/g) || []).length;
    if (openParen > closeParen) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'SyntaxError';
        errorCause = `Thiếu ${openParen - closeParen} dấu đóng ngoặc tròn ')' trong câu lệnh.`;
      }
      fixedLines[i] = rawLine + ')'.repeat(openParen - closeParen);
      continue;
    }

    // 3. Unbalanced square brackets
    const openBracket = (rawLine.match(/\[/g) || []).length;
    const closeBracket = (rawLine.match(/\]/g) || []).length;
    if (openBracket > closeBracket) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'SyntaxError';
        errorCause = `Thiếu dấu đóng ngoặc vuông ']' cho danh sách (list).`;
      }
      fixedLines[i] = rawLine + ']'.repeat(openBracket - closeBracket);
      continue;
    }

    // 4. Invalid assignment in condition: if x = 5: -> if x == 5:
    if (/^(if|elif)\s+[^=><!]+=[^=].*$/.test(trimmed) && !/==/.test(trimmed)) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'SyntaxError';
        errorCause = 'Phép so sánh trong câu lệnh điều kiện `if/elif` phải dùng toán tử `==` (hai dấu bằng), không được dùng phép gán `=`.';
      }
      fixedLines[i] = rawLine.replace(/=([^=])/, '==$1');
      continue;
    }

    // 5. Invalid constant assignment (e.g. 10 = x)
    if (/^[0-9]+(\.[0-9]+)?\s*=\s*/.test(trimmed)) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'SyntaxError';
        errorCause = 'Không thể gán giá trị cho một hằng số số học (vế trái phép gán phải là tên biến).';
      }
      const parts = trimmed.split('=');
      if (parts.length === 2) {
        const val = parts[0].trim();
        const varName = parts[1].trim() || 'gia_tri';
        fixedLines[i] = rawLine.replace(trimmed, `${varName} = ${val}`);
      }
      continue;
    }

    // 6. Unclosed single or double quotes
    const singleQuotes = (trimmed.match(/'/g) || []).length;
    const doubleQuotes = (trimmed.match(/"/g) || []).length;
    if (singleQuotes % 2 !== 0 && !trimmed.includes('"""') && !trimmed.includes("'''")) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'SyntaxError';
        errorCause = 'Chưa đóng dấu nháy đơn (\') cho chuỗi ký tự.';
      }
      fixedLines[i] = rawLine + "'";
      continue;
    }
    if (doubleQuotes % 2 !== 0 && !trimmed.includes('"""') && !trimmed.includes("'''")) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'SyntaxError';
        errorCause = 'Chưa đóng dấu nháy kép (") cho chuỗi ký tự.';
      }
      fixedLines[i] = rawLine + '"';
      continue;
    }

    // 7. Python 2 style print statement
    if (/^print\s+["'].*$/.test(trimmed) && !trimmed.startsWith('print(')) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'SyntaxError';
        errorCause = 'Trong Python 3, hàm `print()` bắt buộc phải có dấu ngoặc tròn bao quanh tham số: `print(...)`.';
      }
      const printArg = trimmed.replace(/^print\s+/, '');
      fixedLines[i] = rawLine.replace(trimmed, `print(${printArg})`);
      continue;
    }

    // 8. Misspelled print function (prnt / prin)
    if (/\b(prnt|prin)\s*\(/.test(trimmed)) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'NameError';
        errorCause = 'Sai chính tả tên hàm in xuất dữ liệu: sửa thành `print(...)`.';
      }
      fixedLines[i] = rawLine.replace(/\b(prnt|prin)\b/g, 'print');
      continue;
    }

    // 9. Zero division
    if (/\/ 0(?![0-9])/.test(trimmed) || /\/=\s*0(?![0-9])/.test(trimmed)) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'ZeroDivisionError';
        errorCause = 'Phép chia cho số 0 không hợp lệ trong toán học và Python.';
      }
      fixedLines[i] = rawLine.replace(/\/ 0(?![0-9])/, '/ 1  # Đã sửa tránh chia cho 0');
      continue;
    }

    // 10. Input without conversion before arithmetic
    if (trimmed.includes('input(') && !trimmed.includes('int(') && !trimmed.includes('float(')) {
      if (errorLine === -1) {
        errorLine = lineNum;
        errorLineContent = rawLine;
        errorType = 'Lưu ý Kiểu Dữ Liệu';
        errorCause = 'Hàm `input()` trả về chuỗi văn bản (str). Nếu dùng tính toán số học, cần ép kiểu `int(...)` hoặc `float(...)`.';
      }
      fixedLines[i] = rawLine.replace(/=\s*input\((.*)\)/, '= int(input($1))');
    }
  }

  if (errorLine === -1) {
    errorLine = 1;
    errorLineContent = lines[0] || '';
    errorType = 'Tối ưu hóa Code';
    errorCause = 'Kiểm tra toàn diện: Tối ưu thụt lề chuẩn PEP 8, làm sạch mã và đảm bảo luồng thực thi an toàn.';
  }

  const cleanCode = formatPep8Locally(fixedLines.join('\n'));

  return `🔍 **Phân tích lỗi mã nguồn:**
- 📍 **Vị trí lỗi:** **Dòng ${errorLine}**: \`${errorLineContent.trim() || '...'}\`
- ⚠️ **Loại lỗi:** \`${errorType || 'SyntaxError'}\`
- 💡 **Nguyên nhân & Cách sửa:** ${errorCause}

⚡ **Mã nguồn đã sửa hoàn chỉnh (Chuẩn Python PEP 8):**
\`\`\`python
${cleanCode.trim()}
\`\`\`

✨ **Điểm đã được sửa chữa & cải tiến:**
1. Khắc phục triệt để lỗi tại **Dòng ${errorLine}**, đảm bảo chương trình chạy trơn tru không bị dừng đột ngột.
2. Chuẩn hóa toàn bộ thụt lề 4 khoảng trắng và cách đặt tên theo chuẩn PEP 8.
3. Mã nguồn đã sẵn sàng: Nhấn nút **"Áp dụng vào Editor"** ngay trên khối code để cập nhật vào trình soạn thảo!`;
}

// Local PEP 8 Python code formatter
function formatPep8Locally(code: string): string {
  if (!code || !code.trim()) {
    return '# Chương trình Python chuẩn PEP 8\ndef main() -> None:\n    """Hàm khởi chạy chính của chương trình."""\n    print("Hello, Pydroid 3!")\n\nif __name__ == "__main__":\n    main()\n';
  }

  const lines = code.split('\n');
  const formattedLines: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const leadingWhitespace = line.match(/^\s*/)?.[0] || '';
    const numTabs = (leadingWhitespace.match(/\t/g) || []).length;
    const numSpaces = (leadingWhitespace.match(/ /g) || []).length;
    const indentLevel = Math.max(0, Math.floor((numTabs * 4 + numSpaces) / 4));
    const properIndent = '    '.repeat(indentLevel);
    const content = line.trim();

    if (!content) {
      formattedLines.push('');
      continue;
    }

    let formattedContent = content
      .replace(/,([^\s])/g, ', $1')
      .replace(/([^\s=!<>])=([^\s=])/g, '$1 = $2')
      .replace(/([^\s])\+([^\s])/g, '$1 + $2')
      .replace(/([^\s])\*([^\s*])/g, '$1 * $2');

    // Automatically append missing colon on compound statements
    if (/^(if|elif|else|for|while|def|class|try|except|finally|with)\b/.test(formattedContent) && !formattedContent.endsWith(':') && !formattedContent.includes('#')) {
      formattedContent += ':';
    }

    formattedLines.push(properIndent + formattedContent);
  }

  return formattedLines.join('\n').trim() + '\n';
}

// Generate comprehensive Vietnamese code explanation locally
function generateExplainResponseLocally(code: string): string {
  const analysis = analyzePythonCodeLocally(code);

  const importSection = analysis.imports.length > 0
    ? `  - **Thư viện sử dụng:** ${analysis.imports.map(i => `\`${i}\``).join(', ')}\n`
    : `  - **Thư viện:** Chỉ sử dụng các hàm built-in cơ bản của Python.\n`;

  const functionSection = analysis.functions.length > 0
    ? `  - **Hàm định nghĩa:** ${analysis.functions.map(f => `\`def ${f}()\``).join(', ')}\n`
    : `  - **Cấu trúc:** Thực thi tuần tự theo kịch bản script.\n`;

  const logicSection = [];
  if (analysis.hasInput) logicSection.push('nhận tương tác dữ liệu từ bàn phím qua `input()`');
  if (analysis.hasLoops) logicSection.push('sử dụng vòng lặp để xử lý dữ liệu');
  if (analysis.hasConditionals) logicSection.push('rẽ nhánh điều kiện logic (`if-elif-else`)');
  if (analysis.hasPrint) logicSection.push('xuất kết quả ra màn hình với `print()`');

  const notes = [
    'Tuân thủ quy tắc thụt lề 4 khoảng trắng chuẩn PEP 8 cho các khối lệnh.',
    'Đặt tên biến và hàm theo phong cách `snake_case` (ví dụ: `my_variable`, `tinh_tong`).',
  ];
  if (analysis.hasInput) {
    notes.push('Dữ liệu từ `input()` luôn là kiểu chuỗi `str`, cần ép kiểu `int()` hoặc `float()` khi tính toán số học.');
  }
  if (analysis.hasLoops) {
    notes.push('Đảm bảo điều kiện dừng trong vòng lặp để tránh hiện tượng vòng lặp vô tận (infinite loop).');
  }

  return `📖 **Giải thích chi tiết mã nguồn Python:**

### 1. 🎯 Tổng quan & Mục đích
- Chương trình gồm **${analysis.linesCount} dòng mã**.
${importSection}${functionSection}- **Luồng xử lý chính:** ${logicSection.length > 0 ? logicSection.join(', ') : 'Xử lý các biểu thức logic cơ bản'}.

### 2. ⚡ Luồng thực thi (Execution Flow)
1. **Khởi tạo:** Trình thông dịch Python nạp mã từ dòng đầu tiên, khai báo các thư viện và định nghĩa hàm (nếu có).
2. **Xử lý:** ${analysis.hasInput ? 'Chờ người dùng nhập dữ liệu qua console, sau đó ' : ''}tính toán và xử lý tuần tự qua từng khối lệnh.
3. **Kết thúc:** ${analysis.hasPrint ? 'In kết quả hoàn tất ra màn hình Terminal.' : 'Hoàn tất kịch bản với mã thoát 0 (Exit Code 0).' }

### 3. ⚠️ Các điểm cần lưu ý
${notes.map(n => `- ${n}`).join('\n')}

💡 *Gợi ý: Bạn có thể nhấn nút **"Tối ưu PEP 8"** kế bên để chuẩn hóa toàn bộ code ngay lập tức, hoặc đặt bất kỳ câu hỏi nào trong ô chat bên dưới!*`;
}

// REST endpoint: Gemini AI Debugger with auto-fallback
app.post('/api/ai/debug', async (req, res) => {
  const { code = '', errorText = '' } = req.body;
  if (!code && !errorText) {
    return res.status(400).json({ error: 'Thiếu thông tin mã hoặc lỗi' });
  }

  const { aiClient, hasKey, isCustom, hasServerKey } = getAiClient(req);

  // 1. Try Gemini API with multi-model fallback & timeout (when key is present)
  if (hasKey) {
    try {
    const prompt = `Bạn là Trình gỡ lỗi Python AI thông minh hàng đầu trên ứng dụng Pydroid 3 Android.
Người dùng đang viết mã Python và gặp lỗi hoặc yêu cầu kiểm tra sửa lỗi sau:

=== MÃ PYTHON HIỆN TẠI ===
${code}

=== THÔNG BÁO LỖI / TRACEBACK ===
${errorText || '(Phân tích toàn bộ cú pháp, phát hiện lỗi cú pháp, thụt lề, chia cho 0 hoặc lỗi runtime và sửa lỗi chuẩn PEP 8)'}

Nhiệm vụ của bạn:
1. Nhận diện chính xác tên loại lỗi (ví dụ: SyntaxError, IndentationError, ZeroDivisionError, NameError, TypeError, IndexError, ValueError, AttributeError...).
2. Giải thích nguyên nhân gốc rễ bằng tiếng Việt chuẩn mực, ngắn gọn, thân thiện, dễ hiểu cho người học lập trình trên điện thoại.
3. Đưa ra danh sách các mẹo khắc phục và quy tắc chuẩn PEP 8 liên quan.
4. Cung cấp phiên bản mã Python ĐÃ ĐƯỢC SỬA HOÀN CHỈNH, chuẩn PEP 8, chạy đúng đắn mà không làm thay đổi ý đồ thuật toán của người dùng.
5. Tóm tắt nhanh dòng/thay đổi quan trọng đã được sửa.

Hãy trả về phản hồi ĐÚNG định dạng JSON theo schema đã cho.`;

    const clientsToTry = isCustom && hasServerKey ? [aiClient, ai] : [aiClient];
    let response: any = null;
    let customError: any = null;
    let lastClientErr: any = null;

    for (const activeClient of clientsToTry) {
      try {
        response = await callWithModelFallback(async (modelName) => {
          const baseConfig: any = {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                errorType: { type: Type.STRING },
                vietnameseSummary: { type: Type.STRING },
                rootCause: { type: Type.STRING },
                tips: { type: Type.ARRAY, items: { type: Type.STRING } },
                fixedCode: { type: Type.STRING },
                diffExplanation: { type: Type.STRING },
              },
              required: ['errorType', 'vietnameseSummary', 'rootCause', 'tips', 'fixedCode', 'diffExplanation'],
            },
          };
          try {
            const modelConfig = supportsThinkingConfig(modelName)
              ? { ...baseConfig, thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } }
              : baseConfig;
            return await withTimeout(
              activeClient.models.generateContent({
                model: modelName,
                contents: prompt,
                config: modelConfig,
              }),
              35000
            );
          } catch (err: any) {
            const status = (err?.status as number) || (err?.statusCode as number);
            if (status === 400 && supportsThinkingConfig(modelName) && !isAuthOrPermissionError(err)) {
              return await withTimeout(
                activeClient.models.generateContent({
                  model: modelName,
                  contents: prompt,
                  config: baseConfig,
                }),
                35000
              );
            }
            throw err;
          }
        });
        if (response?.text) break;
      } catch (clientErr: any) {
        if (isCustom && activeClient === aiClient) customError = clientErr;
        lastClientErr = clientErr;
      }
    }

    if (!response) throw (customError || lastClientErr || new Error('Không nhận được phản hồi từ mô hình'));

    const parsed = JSON.parse(response.text || '{}');
    if (parsed.errorType && parsed.fixedCode) {
      return res.json(parsed);
    }
  } catch (err: any) {
    const diag = classifyServerAiError(err);
    printTerminalAiDiagnostic({
      endpoint: '/api/ai/debug',
      operation: 'AI Debugger',
      failureType: diag.failureType,
      errorMessage: extractFriendlyGeminiError(err).friendly,
      remediation: diag.remediation,
    });
    console.log('[AI Debugger] Kích hoạt bộ phân tích lỗi dự phòng chuẩn PEP 8.');
  }
}

  // 2. Intelligent Rule-Based Fallback Debugger (Guarantees zero-failure response)
  const localAnalysis = analyzeAndFixLocally(code, errorText);
  const codeMatch = localAnalysis.match(/```python\s*([\s\S]*?)```/);
  const fixedCode = (codeMatch && codeMatch[1]) ? codeMatch[1].trim() : formatPep8Locally(code);

  const safeErrStr = String(errorText || '');
  const errMatch = safeErrStr.match(/([A-Za-z]+Error|[A-Za-z]+Exception): (.*)/);
  const detectedType = errMatch ? errMatch[1] : 'SyntaxError';
  const detail = errMatch ? errMatch[2] : (safeErrStr.slice(0, 100) || 'Lỗi cú pháp hoặc runtime');

  res.json({
    errorType: detectedType,
    vietnameseSummary: `Phát hiện lỗi ${detectedType}: ${detail}`,
    rootCause: `Chương trình gặp vấn đề trong quá trình thực thi: ${detail}. Đã tự động phân tích và khắc phục dòng lỗi chuẩn PEP 8.`,
    tips: [
      'Kiểm tra kỹ cú pháp và thụt lề 4 khoảng trắng chuẩn PEP 8.',
      'Sử dụng khối try...except để bao bọc các thao tác có khả năng gây lỗi.',
      'Đảm bảo các biến đã được khai báo trước khi sử dụng.',
    ],
    fixedCode,
    diffExplanation: 'Đã sửa chữa triệt để lỗi cú pháp/runtime và chuẩn hóa PEP 8 100%.',
  });
});

// REST endpoint: Gemini AI Exercise Generator with robust fallback
app.post('/api/ai/generate-lessons', async (req, res) => {
  const {
    topic = 'Python cơ bản & Thực hành',
    level = 'cơ bản',
    existingTitles = [],
    completedTitles = [],
  } = req.body;
  const safeTopic = (typeof topic === 'string' && topic.trim()) ? topic.trim() : 'Python ứng dụng thực tế';
  const cleanExistingTitles = Array.isArray(existingTitles) ? existingTitles.filter(Boolean) : [];
  const cleanCompletedTitles = Array.isArray(completedTitles) ? completedTitles.filter(Boolean) : [];

  const { aiClient, hasKey, isCustom, hasServerKey } = getAiClient(req);

  // 1. Try Gemini API with timeout (when key is available)
  if (hasKey) {
    try {
    const prompt = `Bạn là Giảng viên Chuyên gia Lập trình Python cao cấp cho ứng dụng Pydroid 3 Web trên Android.
Nhiệm vụ: Hãy tạo 2 đến 3 bài tập thực hành Python HOÀN TOÀN MỚI, SÁNG TẠO theo chủ đề: "${safeTopic}" và cấp độ: "${level}".

🚨 QUY TẮC BẮT BUỘC SỐ 1: BÀI HỌC PHẢI HOÀN TOÀN MỚI, KHÔNG TRÙNG LẶP VỚI BÀI ĐÃ CÓ / ĐÃ HỌC:
Dưới đây là danh sách tiêu đề các bài tập người dùng ĐÃ CÓ / ĐÃ HỌC trong kho bài:
${cleanExistingTitles.length > 0 ? cleanExistingTitles.slice(-30).map((t: string) => `- ${t}`).join('\n') : '(Kho bài hiện đang trống)'}

-> YÊU CẦU ĐỘC QUYỀN VỀ TÍNH MỚI LẠ:
- Các bài học tạo ra phải HOÀN TOÀN MỚI, KHÁC BIỆT 100% về tiêu đề, cốt truyện, tình huống và ý tưởng so với danh sách trên.
- Sáng tạo các bài toán thực tế thú vị, gần gũi với đời sống (ví dụ: tính tiền quán trà sữa/cà phê, quản lý chi tiêu học sinh, tính tiền điện sinh hoạt, xếp loại học lực, vé xe buýt, trò chơi dân gian ô ăn quan, kiểm tra mật khẩu an toàn, xử lý chuỗi tiếng Việt...).

🚨 QUY TẮC BẮT BUỘC SỐ 2: VIỆT HÓA 100% TÊN BIẾN, TÊN HÀM VÀ THAM SỐ (BẮT BUỘC 100% TIẾNG VIỆT):
- Cả trong starterCode và solutionCode: 100% TẤT CẢ các tên biến (variables), tên hàm (functions), tham số (parameters) PHẢI ĐƯỢC VIỆT HÓA HOÀN TOÀN bằng tiếng Việt không dấu chuẩn snake_case.
- VÍ DỤ ĐÚNG (VIỆT HÓA 100%):
  + Tên biến: so_thu_nhat, so_thu_hai, tong_tien, danh_sach_diem, chieu_dai, chieu_rong, dien_tich, chu_vi, so_luong, don_gia, ten_hoc_sinh, diem_trung_binh, ket_qua, gia_tri_lon_nhat, so_may_man, chuoi_van_ban, dem_so_chan...
  + Tên hàm: tinh_tong_tien(), tim_so_lon_nhat(), dem_so_nguyen_to(), tinh_diem_trung_binh(), kiem_tra_nam_nhuan(), xu_ly_danh_sach()...
- ❌ TUYỆT ĐỐI CẤM (0% TIẾNG ANH CHO TÊN BIẾN/HÀM):
  Không được dùng bất kỳ tên biến hoặc tên hàm tiếng Anh nào như: x, y, z, a, b, c, i, j, k, n, arr, lst, num, nums, numbers, data, items, val, res, result, total, temp, user_input, count, flag, my_func, process_data, item, test...
  (Ngoại trừ các từ khóa bắt buộc cú pháp của ngôn ngữ Python: def, class, return, if, elif, else, for, in, while, import, print, input, range, len, int, float, str, list, dict, set, tuple, True, False, None, try, except, self).
- Toàn bộ ghi chú (# TODO) và chuỗi in print(...) phải bằng tiếng Việt tự nhiên, rõ ràng.

Mỗi bài tập cần có:
- id: chuỗi id duy nhất dạng snake_case (bắt đầu bằng lesson_ai_...)
- title: Tiêu đề bài tập ngắn gọn, cuốn hút bằng tiếng Việt
- level: một trong 3 giá trị ('basic', 'intermediate', 'advanced')
- description: Đề bài chi tiết bằng tiếng Việt, yêu cầu đầu vào (input) và đầu ra (output) rõ ràng
- starterCode: Khung mã ban đầu kèm comment hướng dẫn (# TODO) với 100% tên biến tiếng Việt
- solutionCode: Lời giải hoàn chỉnh chuẩn mực PEP 8 với 100% tên biến tiếng Việt
- explanation: Giải thích chi tiết thuật toán và kiến thức cốt lõi bằng tiếng Việt
- sampleInput: Ví dụ dữ liệu STDIN mẫu (nếu bài toán có input)
- sampleOutput: Ví dụ kết quả in ra màn hình tương ứng

Hãy xuất kết quả hoàn toàn bằng tiếng Việt chuẩn theo định dạng JSON.`;

    const clientsToTry = isCustom && hasServerKey ? [aiClient, ai] : [aiClient];
    let response: any = null;
    let customError: any = null;
    let lastClientErr: any = null;

    for (const activeClient of clientsToTry) {
      try {
        response = await callWithModelFallback(async (modelName) => {
          const baseConfig: any = {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                lessons: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      title: { type: Type.STRING },
                      level: { type: Type.STRING },
                      description: { type: Type.STRING },
                      starterCode: { type: Type.STRING },
                      solutionCode: { type: Type.STRING },
                      explanation: { type: Type.STRING },
                      sampleInput: { type: Type.STRING },
                      sampleOutput: { type: Type.STRING },
                    },
                    required: ['id', 'title', 'level', 'description', 'starterCode', 'solutionCode', 'explanation'],
                  },
                },
              },
              required: ['lessons'],
            },
          };
          try {
            const modelConfig = supportsThinkingConfig(modelName)
              ? { ...baseConfig, thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } }
              : baseConfig;
            return await withTimeout(
              activeClient.models.generateContent({
                model: modelName,
                contents: prompt,
                config: modelConfig,
              }),
              45000
            );
          } catch (err: any) {
            const status = (err?.status as number) || (err?.statusCode as number);
            if (status === 400 && supportsThinkingConfig(modelName) && !isAuthOrPermissionError(err)) {
              return await withTimeout(
                activeClient.models.generateContent({
                  model: modelName,
                  contents: prompt,
                  config: baseConfig,
                }),
                45000
              );
            }
            throw err;
          }
        });
        if (response?.text) break;
      } catch (clientErr: any) {
        if (isCustom && activeClient === aiClient) customError = clientErr;
        lastClientErr = clientErr;
      }
    }

    if (!response) throw (customError || lastClientErr || new Error('Không nhận được phản hồi từ mô hình'));

    const parsed = JSON.parse(response.text || '{"lessons":[]}');
    if (parsed.lessons && Array.isArray(parsed.lessons) && parsed.lessons.length > 0) {
      // Post-process to guarantee 100% Vietnamese variables and no duplicate titles
      const sanitized = parsed.lessons.map(ensureVietnameseLessonQuality);
      return res.json({ lessons: sanitized });
    }
  } catch (err: any) {
    const diag = classifyServerAiError(err);
    printTerminalAiDiagnostic({
      endpoint: '/api/ai/generate-lessons',
      operation: 'Generate Lessons',
      failureType: diag.failureType,
      errorMessage: extractFriendlyGeminiError(err).friendly,
      remediation: diag.remediation,
    });
    console.log('[AI Lessons] Kích hoạt tạo kho bài học dự phòng chất lượng cao.');
  }
}

  // 2. High-Quality Fallback Generation (Instantly returns custom lessons without failing!)
  const fallbackLessons = getFallbackLessons(safeTopic, level, cleanExistingTitles);
  res.json({ lessons: fallbackLessons });
});

// Helper to build chat prompt payload and system instructions
function buildChatPayload(code: string, messages: any[], instruction: string, errorText: string) {
  const codeLines = (code || '').split('\n');
  const numberedCode = codeLines
    .map((l: string, idx: number) => `${idx + 1}: ${l}`)
    .join('\n');

  const rawMessages = Array.isArray(messages) ? messages : [];
  const lastUserMsg = [...rawMessages].reverse().find((m: any) => m && m.sender === 'user') || rawMessages[rawMessages.length - 1];
  const rawUserText = String(lastUserMsg?.text || '').toLowerCase();
  const isFixErrorRequest =
    instruction === 'fix_error' ||
    instruction === 'analyze_fix_clean' ||
    /s[uư][aảã].*l[oô][iỉĩ]|l[oô][iỉĩ]|fix.*error|fix.*bug|debug|g[oỡ].*l[oô][iỉĩ]|b[iị].*l[oô][iỉĩ]|d[oò]ng.*m[aấ]y.*l[oô][iỉĩ]|s[uư][aảã].*code/i.test(rawUserText);

  const systemInstruction = `Bạn là Trợ lý AI Lập trình Python thông minh, tận tâm và chuyên nghiệp trên ứng dụng Pydroid 3 Web cho Android.
Nhiệm vụ của bạn là hỗ trợ người dùng học, viết, phân tích, tối ưu và gỡ lỗi/sửa lỗi mã Python.

Quy tắc quan trọng:
1. Luôn sử dụng tiếng Việt thân thiện, rõ ràng, dễ hiểu cho cả người mới bắt đầu lẫn người đã có kinh nghiệm.
2. Ngữ cảnh mã nguồn hiện tại trong Editor của người dùng (kèm số thứ tự dòng tương ứng):
\`\`\`python
${numberedCode || '# 1: (Chưa có mã nguồn trong Editor)'}
\`\`\`
${errorText ? `\n⚠️ Thông báo lỗi hoặc Traceback ghi nhận gần nhất từ Terminal:\n\`\`\`\n${errorText}\n\`\`\`\n` : ''}
3. Ghi nhớ toàn bộ lịch sử trò chuyện (multi-turn conversation) để trả lời mạch lạc câu hỏi của người dùng.
4. Khi đưa ra gợi ý code hoặc viết lại code, luôn bọc trong khối code markdown \`\`\`python ... \`\`\` (tuyệt đối KHÔNG kèm số thứ tự dòng trong khối code hoàn chỉnh này) để giao diện người dùng có thể hiển thị nút "Sao chép mã" và "Áp dụng vào Editor" với 1-chạm.
5. Tuân thủ nghiêm ngặt chuẩn PEP 8 của Python: thụt lề 4 khoảng trắng, đặt tên biến snake_case, xử lý ngoại lệ an toàn và tối ưu kiểu Pythonic.
6. Khi người dùng yêu cầu SỬA LỖI (fix error, debug, "sửa lỗi", "sửa lổi", "phân tích lỗi", "lỗi dòng nào & viết gọn lại", hoặc instruction 'fix_error' / 'analyze_fix_clean'):
   - 📍 **Vị trí dòng lỗi:** BẮT BUỘC chỉ rõ chính xác lỗi xuất hiện ở dòng số mấy (ví dụ: "📍 **Lỗi ở Dòng X:** \`...\`").
   - ⚠️ **Nguyên nhân lỗi:** Giải thích rõ ràng nguyên nhân tại sao dòng đó bị lỗi (lỗi cú pháp SyntaxError, thụt lề IndentationError, chia cho 0, biến chưa khai báo NameError, lỗi kiểu TypeError, logic vòng lặp while True, nhập liệu input không an toàn...).
   - ⚡ **Mã nguồn mới HOÀN CHỈNH ĐÃ ĐƯỢC SỬA LỖI 100%:** Cung cấp toàn bộ đoạn mã HOÀN CHỈNH, CHẠY ĐƯỢC NGAY KHÔNG CÒN LỖI, ngắn gọn, sạch sẽ hơn mã hiện tại theo chuẩn PEP 8 và phong cách Pythonic, đặt trong khối \`\`\`python ... \`\`\`.
   - 💡 **Các điểm cải tiến:** Nêu ngắn gọn các điểm đã làm sạch và sửa chữa mã.
7. Nếu người dùng mới mở chat (chưa có câu hỏi nào) hoặc yêu cầu giải thích ban đầu: Hãy tóm tắt nhanh mã nguồn hiện tại, nêu mục đích hoạt động, cấu trúc chính và gợi ý các hướng nâng cấp tiếp theo.`;

  let userPrompt = '';
  if (isFixErrorRequest) {
    userPrompt = lastUserMsg?.text && lastUserMsg.text.length > 5
      ? `${lastUserMsg.text}\n\n(Yêu cầu: Chỉ rõ dòng lỗi, nguyên nhân và cung cấp mã Python hoàn chỉnh ĐÃ SỬA LỖI 100% trong khối \`\`\`python ... \`\`\` để nạp vào Editor)`
      : 'Hãy phân tích chi tiết lỗi trong mã nguồn hiện tại: chỉ rõ lỗi ở dòng nào (dòng số mấy), nguyên nhân gây lỗi là gì, và viết ra code mới đã sửa hoàn chỉnh 100% chạy đúng đắn theo chuẩn Python PEP 8.';
  } else if (instruction === 'explain_source_code' || instruction === 'initial_explain') {
    userPrompt = lastUserMsg?.text || 'Hãy giải thích chi tiết mã nguồn Python này, luồng thực thi và các điểm cần lưu ý.';
  } else if (instruction === 'optimize_pep8') {
    userPrompt = lastUserMsg?.text || 'Hãy tối ưu và chuẩn hóa toàn bộ mã nguồn Python này theo tiêu chuẩn PEP 8 chính thức: thụt lề 4 khoảng trắng, đặt tên biến/hàm theo snake_case rõ ràng, thêm type hints/docstring ngắn gọn, viết theo phong cách Pythonic gọn gàng, loại bỏ mã thừa. Cung cấp mã hoàn chỉnh trong khối ```python ... ``` để người dùng có thể bấm Áp dụng vào Editor ngay lập tức.';
  } else if (instruction === 'explain_line_by_line') {
    userPrompt = lastUserMsg?.text || 'Hãy giải thích chi tiết từng dòng trong đoạn mã Python hiện tại của mình một cách dễ hiểu nhất.';
  } else if (instruction === 'pythonic') {
    userPrompt = lastUserMsg?.text || 'Hãy viết lại đoạn mã này theo phong cách Pythonic ngắn gọn, tối ưu và đẹp mắt nhất chuẩn PEP 8.';
  } else if (instruction === 'try_except') {
    userPrompt = lastUserMsg?.text || 'Hãy bổ sung khối bắt lỗi ngoại lệ try...except cho các vị trí có nguy cơ xảy ra lỗi trong mã này.';
  } else if (instruction === 'add_comments') {
    userPrompt = lastUserMsg?.text || 'Hãy thêm các chú thích (comment) tiếng Việt chi tiết, rõ ràng vào từng phần quan trọng của đoạn mã này.';
  } else if (instruction === 'test_data') {
    userPrompt = lastUserMsg?.text || 'Hãy cho mình một số bộ ví dụ dữ liệu chạy thử (input và output mong đợi) kèm giải thích cho đoạn code này.';
  } else {
    userPrompt = lastUserMsg?.text || 'Hãy phân tích mã nguồn hiện tại của mình.';
  }

  // Clean and normalize multi-turn chat history for Gemini API:
  // Rule 1: The first turn must always have role 'user' (drop any leading assistant greetings)
  // Rule 2: Alternating roles (merge consecutive identical roles)
  // Rule 3: The last turn is our enriched prompt with code context
  const previousTurns = rawMessages.slice(0, -1);
  const normalizedHistory: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

  for (const item of previousTurns) {
    if (!item || typeof item.text !== 'string' || !item.text.trim()) continue;
    const role: 'user' | 'model' = item.sender === 'user' ? 'user' : 'model';
    const text = item.text.trim();

    // Discard leading assistant/model greeting turns before the first user turn
    if (normalizedHistory.length === 0 && role === 'model') {
      continue;
    }

    if (normalizedHistory.length > 0 && normalizedHistory[normalizedHistory.length - 1].role === role) {
      normalizedHistory[normalizedHistory.length - 1].parts[0].text += `\n\n${text}`;
    } else {
      normalizedHistory.push({ role, parts: [{ text }] });
    }
  }

  // Ensure the preceding turn was 'model' so appending the new 'user' prompt alternates cleanly
  while (normalizedHistory.length > 0 && normalizedHistory[normalizedHistory.length - 1].role === 'user') {
    normalizedHistory.pop();
  }

  const finalUserTurn = {
    role: 'user' as const,
    parts: [
      {
        text: `[Ngữ cảnh mã nguồn Python hiện tại trong Editor]:\n\`\`\`python\n${numberedCode || '# (Trống)'}\n\`\`\`\n${errorText ? `\n[Thông báo lỗi / Traceback gần nhất từ Terminal]:\n\`\`\`\n${errorText}\n\`\`\`\n` : ''}\n\n[Yêu cầu của người dùng]:\n${userPrompt}`,
      },
    ],
  };

  const contents = [...normalizedHistory, finalUserTurn];
  return { contents, systemInstruction };
}

// Intelligent contextual Python code generator for games, requests, and feature expansions
function generateContextualPythonCode(prompt: string, existingCode: string): string | null {
  const raw = (prompt || '').toLowerCase().trim();
  if (!raw) return null;

  // 1. Dice Game: Player vs Computer (Xúc xắc: Người dùng chơi với máy / Đối kháng máy tính)
  const isDiceKeyword = /x[uú]c\s*x[aắ]c|dice|xuc\s*xac/i.test(raw) || (existingCode && existingCode.includes('xuc_xac'));
  const isPlayVsBot = /ch[oơ]i.*(m[aá]y|bot)|ng[uư][oờ]i.*(m[aá]y|bot)|choi.*may|nguoi.*may|v[oớ]i\s+m[aá]y|đ[oố]i\s*kh[aá]ng|vs\s*bot|vs\s*computer/i.test(raw);

  if ((isDiceKeyword && isPlayVsBot) || (/x[uú]c\s*x[aắ]c/i.test(raw) && /ch[oơ]i|game/i.test(raw)) || (/vi[eế]t.*th[eê]m.*code.*ch[oơ]i/i.test(raw))) {
    return `🎲 **Trò chơi Đổ Xúc Xắc: Người Chơi vs Máy Tính (Chuẩn PEP 8):**

Dưới đây là mã nguồn Python hoàn chỉnh đã được bổ sung đầy đủ tính năng người dùng đối kháng với máy tính, có tính điểm từng ván và hỏi người chơi có muốn tiếp tục hay không:

\`\`\`python
"""
Trò chơi Đổ Xúc Xắc: Người Chơi vs Máy Tính (PEP 8 Standard)
Tương thích hoàn hảo với Pydroid 3 Web & Android Terminal.
"""
import random
import time


def do_xuc_xac() -> int:
    """Tung một con xúc xắc ngẫu nhiên từ 1 đến 6 điểm."""
    return random.randint(1, 6)


def choi_mot_van(van_so: int) -> tuple[int, int]:
    """Thực hiện một ván đấu giữa Người chơi và Máy tính."""
    print(f"\\n🎲 ================== VÁN {van_so} ==================")
    input("👉 Nhấn [Enter] để tung xúc xắc của bạn...")

    diem_nguoi = do_xuc_xac()
    print(f"👤 Bạn đã tung được : {diem_nguoi} điểm 🎲")

    print("🤖 Máy tính đang tung xúc xắc...")
    time.sleep(0.5)
    diem_may = do_xuc_xac()
    print(f"🤖 Máy tính tung được: {diem_may} điểm 🎲")

    if diem_nguoi > diem_may:
        print("🎉 Chúc mừng! BẠN ĐÃ THẮNG ván này!")
    elif diem_nguoi < diem_may:
        print("😢 Rất tiếc, Máy tính đã thắng ván này!")
    else:
        print("🤝 Kết quả hòa! Cả hai bên đều bằng điểm.")

    return diem_nguoi, diem_may


def main() -> None:
    """Hàm điều khiển luồng chính của trò chơi."""
    print("=" * 50)
    print(" 🎲 GAME ĐỔ XÚC XẮC: NGƯỜI CHƠI VS MÁY TÍNH 🎲 ")
    print("=" * 50)

    thang_nguoi = 0
    thang_may = 0
    hoa = 0
    van_so = 1

    while True:
        diem_nguoi, diem_may = choi_mot_van(van_so)

        if diem_nguoi > diem_may:
            thang_nguoi += 1
        elif diem_nguoi < diem_may:
            thang_may += 1
        else:
            hoa += 1

        print(f"\\n📊 TỔNG TỶ SỐ: Bạn [{thang_nguoi}] - Máy [{thang_may}] - Hòa [{hoa}]")

        tiep_tuc = input("\\nBạn có muốn chơi tiếp ván nữa không? (y/n): ").strip().lower()
        if tiep_tuc not in ("y", "yes", "co", "c", "1"):
            print("\\n👋 Cảm ơn bạn đã trải nghiệm trò chơi! Hẹn gặp lại!")
            break

        van_so += 1


if __name__ == "__main__":
    main()
\`\`\`

✨ **Các cải tiến đã thêm:**
1. **Tương tác trực tiếp:** Người chơi nhấn \`Enter\` để tung xúc xắc của mình.
2. **Cơ chế máy tính tự động:** Máy tính tự động tung ngẫu nhiên và so sánh kết quả.
3. **Bảng điểm liên tục:** Lưu giữ tỷ số thắng/thua/hòa qua các ván đấu.
4. **Chuẩn PEP 8:** Thụt lề 4 khoảng trắng, type hints rõ ràng, khối \`if __name__ == "__main__":\`.

👉 *Nhấn nút **"Áp dụng vào Editor"** ngay trên khối code để nạp vào trình soạn thảo và bấm nút **RUN** màu vàng để chơi ngay!*`;
  }

  // 2. Number guessing game (Trò chơi đoán số)
  if (/đo[aá]n\s+s[oố]|guessing|guess.*number/i.test(raw)) {
    return `🎯 **Trò chơi Đoán Số Bí Mật (Chuẩn PEP 8):**

\`\`\`python
import random


def choi_doan_so() -> None:
    """Trò chơi đoán số ngẫu nhiên từ 1 đến 100."""
    so_bi_mat = random.randint(1, 100)
    so_lan_doan = 0
    print("🎯 Chào mừng bạn đến với Game Đoán Số (1 - 100)!")

    while True:
        try:
            doan = int(input("👉 Nhập số bạn đoán (1-100): "))
            so_lan_doan += 1
            if doan < so_bi_mat:
                print("📈 Quá nhỏ! Hãy thử số lớn hơn.")
            elif doan > so_bi_mat:
                print("📉 Quá lớn! Hãy thử số nhỏ hơn.")
            else:
                print(f"🎉 Xuất sắc! Bạn đã đoán đúng số {so_bi_mat} sau {so_lan_doan} lần.")
                break
        except ValueError:
            print("⚠️ Vui lòng nhập số nguyên hợp lệ!")


if __name__ == "__main__":
    choi_doan_so()
\`\`\`

👉 *Nhấn nút **"Áp dụng vào Editor"** ngay trên khối code để nạp vào trình soạn thảo!*`;
  }

  // 3. Rock Paper Scissors (Kéo - Búa - Bao)
  if (/k[eé]o\s+b[uú]a\s+bao|o[aẳ]n\s+t[uù]\s+t[iì]|rock.*paper.*scissors/i.test(raw)) {
    return `✂️ **Trò chơi Kéo - Búa - Bao: Người Chơi vs Máy Tính (Chuẩn PEP 8):**

\`\`\`python
import random

LUA_CHON = ["kéo", "búa", "bao"]


def choi_keo_bua_bao() -> None:
    print("✂️🔨📄 GAME KÉO - BÚA - BAO ✂️🔨📄")
    while True:
        nguoi = input("\\nNhập lựa chọn của bạn (kéo, búa, bao) hoặc 'thoat': ").strip().lower()
        if nguoi == "thoat":
            print("👋 Tạm biệt bạn!")
            break
        if nguoi not in LUA_CHON:
            print("⚠️ Lựa chọn không hợp lệ, hãy nhập: kéo, búa hoặc bao.")
            continue

        may = random.choice(LUA_CHON)
        print(f"🤖 Máy tính chọn: {may}")

        if nguoi == may:
            print("🤝 Hòa nhau!")
        elif (
            (nguoi == "kéo" and may == "bao")
            or (nguoi == "búa" and may == "kéo")
            or (nguoi == "bao" and may == "búa")
        ):
            print("🎉 BẠN THẮNG!")
        else:
            print("😢 MÁY TÍNH THẮNG!")


if __name__ == "__main__":
    choi_keo_bua_bao()
\`\`\`

👉 *Nhấn nút **"Áp dụng vào Editor"** ngay trên khối code để nạp vào trình soạn thảo!*`;
  }

  // 4. Algorithms / Math / Factorial / Primes / Fibonacci
  if (/nguy[eê]n\s+t[oố]|fibonacci|giai\s+th[uừ]a|ucln|bcnn/i.test(raw)) {
    return `💡 **Chương trình Python Xử Lý Toán Học Thuật Toán (Chuẩn PEP 8):**

\`\`\`python
def kiem_tra_nguyen_to(n: int) -> bool:
    """Kiểm tra số nguyên tố tối ưu O(sqrt(N))."""
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True


def day_fibonacci(n: int) -> list[int]:
    """Tạo danh sách N số Fibonacci đầu tiên."""
    if n <= 0:
        return []
    if n == 1:
        return [0]
    fib = [0, 1]
    for _ in range(2, n):
        fib.append(fib[-1] + fib[-2])
    return fib


def main() -> None:
    print("--- CHƯƠNG TRÌNH XỬ LÝ TOÁN HỌC PYTHON ---")
    try:
        n = int(input("Nhập một số nguyên dương N: "))
        print(f"Số {n} là số nguyên tố? -> {'CÓ' if kiem_tra_nguyen_to(n) else 'KHÔNG'}")
        print(f"Dãy {n} số Fibonacci đầu tiên: {day_fibonacci(n)}")
    except ValueError:
        print("⚠️ Vui lòng nhập số nguyên hợp lệ!")


if __name__ == "__main__":
    main()
\`\`\`

👉 *Nhấn nút **"Áp dụng vào Editor"** ngay trên khối code để nạp vào trình soạn thảo!*`;
  }

  // 5. General "viết code", "viết thêm", "thêm tính năng"
  if (/vi[eế]t.*code|th[eê]m.*code|vi[eế]t.*h[aà]m|vi[eế]t.*ch[uư][oơ]ng\s*tr[iì]nh|t[aạ]o.*code/i.test(raw)) {
    if (existingCode && existingCode.trim().length > 10) {
      const formatted = formatPep8Locally(existingCode);
      return `💡 **Mã nguồn Python theo yêu cầu của bạn (Chuẩn PEP 8):**

\`\`\`python
${formatted}
\`\`\`

✨ **Điểm nổi bật:**
- Đã được chuẩn hóa theo tiêu chuẩn **PEP 8** chính thức.
- Sẵn sàng nhấn nút **"Áp dụng vào Editor"** phía trên khối code để nạp trực tiếp vào trình soạn thảo!`;
    }
  }

  return null;
}

// Guaranteed smart fallback generator for offline or connection issues
function generateLocalChatFallback(code: string, messages: any[], instruction: string, errorText: string): string {
  const lastUserMsg = messages[messages.length - 1];
  const userText = String(lastUserMsg?.text || '').trim();
  const rawUserText = userText.toLowerCase();

  const isErrorAnalysis =
    instruction === 'fix_error' ||
    instruction === 'analyze_fix_clean' ||
    /s[uư][aảã].*l[oô][iỉĩ]|l[oô][iỉĩ]|fix.*error|fix.*bug|debug|g[oỡ].*l[oô][iỉĩ]|b[iị].*l[oô][iỉĩ]|d[oò]ng.*m[aấ]y.*l[oô][iỉĩ]|s[uư][aảã].*code/i.test(rawUserText);

  // 1. Error analysis / bug fixing request
  if (instruction === 'fix_error' || instruction === 'analyze_fix_clean' || isErrorAnalysis) {
    return analyzeAndFixLocally(code, errorText);
  }

  // 2. Contextual code generation (dice game, player vs bot, number guessing, math, custom code, etc.)
  const contextualCode = generateContextualPythonCode(userText, code);
  if (contextualCode) {
    return contextualCode;
  }

  // 3. Greetings & Salutations (e.g. "xin chào trợ lý")
  if (/^(xin\s+ch[aà]o|ch[aà]o|hello|hi\b|alo|h[eé] l[oô]|ch[aà]o\s+b[aạ]n)/i.test(rawUserText)) {
    return `👋 **Xin chào bạn!** Tôi là **Trợ lý Trí tuệ Nhân tạo Gemini AI** trên Pydroid 3.

Tôi luôn sẵn sàng đồng hành cùng bạn học và lập trình Python:
- 🛠️ **Gỡ lỗi & Sửa mã nguồn:** Tự động phát hiện lỗi, chỉ rõ số dòng và viết lại code hoàn chỉnh chuẩn PEP 8.
- 📖 **Giải thích chi tiết:** Phân tích logic từng dòng mã, cấu trúc hàm và thuật toán.
- ⚡ **Tối ưu hóa Pythonic:** Rút gọn code, tăng tốc độ thực thi, thêm xử lý ngoại lệ \`try...except\`.
- ✍️ **Viết code theo yêu cầu:** Bạn có thể yêu cầu tôi viết bất kỳ chương trình Python nào (toán học, xử lý chuỗi, game, mảng...).

Bạn muốn cùng tôi thực hiện bài toán hoặc chức năng nào ngay bây giờ? Hãy nhắn câu hỏi bên dưới nhé!`;
  }

  // 4. Question about assistant capabilities
  if (/b[aạ]n\s+l[aà]\s+ai|b[aạ]n\s+c[oó]\s+th[eể]|l[aà]m\s+đ[uư][oợ]c\s+g[iì]|gi[uú]p\s+g[iì]|h[uư][oớ]ng\s+d[aẫ]n/i.test(rawUserText)) {
    return `🤖 **Tôi là Trợ lý AI Lập trình Python chuyên biệt cho Pydroid 3 Web & APK!**

Các tính năng nổi bật:
1. **Kiểm tra và sửa lỗi tự động:** Bấm nút **"Sửa lỗi code"** hoặc **"Lỗi dòng nào"** để phân tích mã lỗi từ Terminal.
2. **Chuẩn hóa PEP 8:** Bấm nút **"Tối ưu PEP 8"** để tự động căn lề 4 khoảng trắng, định dạng biến snake_case.
3. **Soạn thảo chương trình:** Nhập yêu cầu bằng tiếng Việt (ví dụ: *"viết game xúc xắc người chơi với máy"*, *"viết hàm kiểm tra số nguyên tố"*...).
4. **Học tập:** Xem kho bài tập phong phú tại biểu tượng 🎓 Mũ cử nhân trên thanh công cụ!`;
  }

  // 5. Optimization & Special instructions
  if (instruction === 'optimize_pep8' || /t[oố]i\s+[uư]u.*pep/i.test(rawUserText)) {
    return `⚡ **Mã nguồn đã tối ưu theo chuẩn PEP 8:**\n\n\`\`\`python\n${formatPep8Locally(code)}\`\`\`\n\n✅ Đã chuẩn hóa thụt lề 4 spaces, định dạng toán tử và cấu trúc hàm theo chuẩn PEP 8 của Python! Sẵn sàng bấm **Áp dụng vào Editor**.`;
  } else if (instruction === 'explain_line_by_line') {
    return `🔍 **Giải thích từng phần mã nguồn:**\n\n- Mã nguồn của bạn đang xử lý các tác vụ logic chính.\n- Các hàm và biến được khởi tạo tuần tự từ trên xuống dưới.\n- Bạn có thể hỏi sâu hơn về bất kỳ dòng code hoặc biến cụ thể nào!`;
  } else if (instruction === 'pythonic') {
    return `⚡ **Cách viết ngắn hơn (Pythonic):**\n\nCó thể áp dụng List Comprehension hoặc hàm built-in tối ưu chuẩn PEP 8:\n\n\`\`\`python\n${formatPep8Locally(code)}\`\`\`\n\nCấu trúc này giúp mã nguồn gọn gàng, tăng tốc độ thực thi và dễ bảo trì.`;
  } else if (instruction === 'try_except') {
    return `🛡️ **Bổ sung bắt lỗi ngoại lệ try...except:**\n\n\`\`\`python\ntry:\n    # Thực thi mã an toàn\n${code ? String(code).split('\n').map((l: string) => '    ' + l).join('\n') : '    pass'}\nexcept Exception as e:\n    print(f"❌ Xảy ra lỗi: {e}")\n\`\`\`\n\nKhối try...except giúp chương trình không bị crash đột ngột khi gặp lỗi nhập liệu.`;
  } else if (instruction === 'add_comments') {
    return `💬 **Mã đã thêm chú thích tiếng Việt:**\n\n\`\`\`python\n# ==========================================\n# 🐍 Chương trình Python\n# ==========================================\n${code ? String(code).split('\n').map((l: string) => l.trim() ? `# Xử lý:\n${l}` : l).join('\n') : '# Viết mã tại đây'}\n\`\`\`\n\nĐã thêm chú thích giúp bạn dễ dàng theo dõi logic.`;
  } else if (instruction === 'test_data') {
    return `🧪 **Ví dụ dữ liệu chạy thử:**\n\n- Trường hợp thông thường: Dữ liệu hợp lệ theo đúng kiểu int / str.\n- Trường hợp biên (Edge case): Số 0, chuỗi rỗng "", hoặc giá trị âm.\n- Bạn có thể chạy thử trực tiếp trong Terminal để kiểm tra kết quả!`;
  }

  // 6. Only explain source code if user explicitly requested explanation
  if (instruction === 'explain_source_code' || instruction === 'initial_explain' || /gi[aả]i\s+th[ií]ch/i.test(rawUserText)) {
    if (code && code.trim()) {
      return generateExplainResponseLocally(code);
    }
  }

  // 7. Fallback general response with helpful suggestion
  if (code && code.trim()) {
    return generateExplainResponseLocally(code);
  }

  return `🤖 Tôi đã nhận được yêu cầu: *"**${userText}**"*. 

Bạn có thể chọn một trong các nút chức năng nhanh phía trên:
- 🛠️ **Sửa lỗi code**: Khắc phục lỗi và tạo mã mới chạy ngay.
- 📖 **Giải thích**: Nắm rõ logic từng phần mã nguồn.
- ✨ **Tối ưu PEP 8**: Chuẩn hóa phong cách lập trình Python chuyên nghiệp.`;
}

// REST endpoint: Gemini AI Streaming Chat (Server-Sent Events)
app.post('/api/ai/chat/stream', async (req, res) => {
  const { code = '', messages = [], instruction = '', errorText = '' } = req.body;
  const { aiClient, hasKey, isCustom, hasServerKey } = getAiClient(req);

  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders?.();
  res.write(': keep-alive\n\n');

  if (!hasKey) {
    const notice =
      '⚠️ **Chưa kết nối được Google Gemini AI:** Máy chủ chưa có `GEMINI_API_KEY` hợp lệ trong AI Studio **Settings > Secrets**.\n\n---\n\n';
    const fallbackText = generateLocalChatFallback(code, messages, instruction, errorText);
    res.write(`data: ${JSON.stringify({ text: `${notice}${fallbackText}` })}\n\n`);
    res.write('data: [DONE]\n\n');
    res.end();
    return;
  }

  try {
    const { contents, systemInstruction } = buildChatPayload(code, messages, instruction, errorText);

    let streamed = false;
    let customError: any = null;
    let lastStreamError: any = null;
    const clientsToTry = isCustom && hasServerKey ? [aiClient, ai] : [aiClient];

    // 1. Attempt streaming across candidate models (auto-fallback to server key if custom key rejected)
    for (const activeClient of clientsToTry) {
      if (streamed) break;

      for (const model of CANDIDATE_MODELS) {
        const tryStream = async (useThinking: boolean): Promise<boolean> => {
          const modelConfig: any = { systemInstruction };
          if (useThinking && supportsThinkingConfig(model)) {
            modelConfig.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
          }

          const streamPromise = activeClient.models.generateContentStream({
            model,
            contents,
            config: modelConfig,
          });

          const stream = await withTimeout(streamPromise, 15000);
          let gotAny = false;
          for await (const chunk of stream) {
            const text = chunk.text || '';
            if (text) {
              res.write(`data: ${JSON.stringify({ text })}\n\n`);
              gotAny = true;
            }
          }
          return gotAny;
        };

        try {
          streamed = await tryStream(true);
          if (streamed) break;
        } catch (streamErr: any) {
          const status = (streamErr?.status as number) || (streamErr?.statusCode as number);
          if (status === 400 && supportsThinkingConfig(model) && !isAuthOrPermissionError(streamErr)) {
            try {
              streamed = await tryStream(false);
              if (streamed) break;
            } catch (retryErr: any) {
              if (isCustom && activeClient === aiClient) customError = retryErr;
              lastStreamError = retryErr;
            }
          } else {
            if (isCustom && activeClient === aiClient) customError = streamErr;
            lastStreamError = streamErr;
          }

          const friendlyNotice = extractFriendlyGeminiError(lastStreamError).friendly;
          console.log(`[AI Streaming] ${model}: ${friendlyNotice}`);

          if (isAuthOrPermissionError(lastStreamError)) {
            break;
          }
          continue;
        }
      }
    }

    // 2. If streaming didn't output chunks, try non-streaming generateContent using the same active clients (custom key first!)
    if (!streamed) {
      for (const activeClient of clientsToTry) {
        if (streamed) break;
        for (const model of CANDIDATE_MODELS) {
          try {
            const modelConfig: any = { systemInstruction };
            const resp = await withTimeout(
              activeClient.models.generateContent({
                model,
                contents,
                config: modelConfig,
              }),
              15000
            );
            if (resp && resp.text) {
              res.write(`data: ${JSON.stringify({ text: resp.text })}\n\n`);
              streamed = true;
              break;
            }
          } catch (genErr: any) {
            if (isCustom && activeClient === aiClient && !customError) customError = genErr;
            lastStreamError = genErr;
            if (isAuthOrPermissionError(genErr)) break;
            continue;
          }
        }
      }
    }

    // 3. If upstream AI models were unavailable or rejected, show exact error notice + local PEP 8 fallback
    if (!streamed) {
      const effectiveError = isCustom ? (customError || lastStreamError) : lastStreamError;
      const friendlyReason = effectiveError
        ? extractFriendlyGeminiError(effectiveError).friendly
        : 'Không nhận được phản hồi từ Google Gemini.';
      const notice = `⚠️ **Chưa kết nối được Google Gemini AI:** ${friendlyReason}\n💡 *Ứng dụng không dùng cổng nhập khóa API thủ công; kết nối AI trực tuyến lấy khóa từ **Settings > Secrets** của dự án Google AI Studio. Bên dưới là kết quả phân tích PEP 8 nội bộ:*\n\n---\n\n`;
      const fallbackText = generateLocalChatFallback(code, messages, instruction, errorText);
      res.write(`data: ${JSON.stringify({ text: `${notice}${fallbackText}` })}\n\n`);
    }

    res.write('data: [DONE]\n\n');
    res.end();
  } catch (err: any) {
    const diag = classifyServerAiError(err);
    const friendlyReason = extractFriendlyGeminiError(err).friendly;
    printTerminalAiDiagnostic({
      endpoint: '/api/ai/chat/stream',
      operation: 'Streaming Chat',
      failureType: diag.failureType,
      errorMessage: friendlyReason,
      remediation: diag.remediation,
    });
    const notice = `⚠️ **Chưa kết nối được Google Gemini AI:** ${friendlyReason}\n\n---\n\n`;
    const fallbackText = generateLocalChatFallback(code, messages, instruction, errorText);
    res.write(`data: ${JSON.stringify({ text: `${notice}${fallbackText}` })}\n\n`);
    res.write('data: [DONE]\n\n');
    res.end();
  }
});

// REST endpoint: Gemini AI Python Coding Assistant Multi-turn Chat
app.post('/api/ai/chat', async (req, res) => {
  const { code = '', messages = [], instruction = '', errorText = '' } = req.body;
  const { aiClient, hasKey, isCustom, hasServerKey } = getAiClient(req);

  if (!hasKey) {
    const notice =
      '⚠️ **Chưa kết nối được Google Gemini AI:** Máy chủ chưa có `GEMINI_API_KEY` hợp lệ trong AI Studio **Settings > Secrets**.\n\n---\n\n';
    const fallback = generateLocalChatFallback(code, messages, instruction, errorText);
    return res.json({ reply: `${notice}${fallback}` });
  }

  try {
    const { contents, systemInstruction } = buildChatPayload(code, messages, instruction, errorText);
    const clientsToTry = isCustom && hasServerKey ? [aiClient, ai] : [aiClient];
    let response: any = null;
    let customError: any = null;
    let lastClientErr: any = null;

    for (const activeClient of clientsToTry) {
      try {
        response = await callWithModelFallback(async (modelName) => {
          try {
            const modelConfig: any = { systemInstruction };
            if (supportsThinkingConfig(modelName)) {
              modelConfig.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
            }
            return await withTimeout(
              activeClient.models.generateContent({
                model: modelName,
                contents,
                config: modelConfig,
              }),
              35000
            );
          } catch (err: any) {
            const status = (err?.status as number) || (err?.statusCode as number);
            if (status === 400 && supportsThinkingConfig(modelName) && !isAuthOrPermissionError(err)) {
              return await withTimeout(
                activeClient.models.generateContent({
                  model: modelName,
                  contents,
                  config: { systemInstruction },
                }),
                35000
              );
            }
            throw err;
          }
        });
        if (response?.text) break;
      } catch (clientErr: any) {
        if (isCustom && activeClient === aiClient) customError = clientErr;
        lastClientErr = clientErr;
      }
    }

    if (!response) throw (customError || lastClientErr || new Error('Không nhận được phản hồi từ mô hình'));

    const replyText = response.text || 'Xin lỗi, mình chưa thể xử lý câu trả lời lúc này.';
    return res.json({ reply: replyText });
  } catch (err: any) {
    const diag = classifyServerAiError(err);
    const friendlyReason = extractFriendlyGeminiError(err).friendly;
    printTerminalAiDiagnostic({
      endpoint: '/api/ai/chat',
      operation: 'Multi-turn Chat',
      failureType: diag.failureType,
      errorMessage: friendlyReason,
      remediation: diag.remediation,
    });
    console.log('[AI Chat] Kích hoạt phân tích thông minh dự phòng.');
    const notice = `⚠️ **Chưa kết nối được Google Gemini AI:** ${friendlyReason}\n💡 *Ứng dụng không dùng cổng nhập khóa API thủ công; kết nối AI trực tuyến lấy khóa từ **Settings > Secrets** của dự án Google AI Studio. Bên dưới là kết quả phân tích PEP 8 nội bộ:*\n\n---\n\n`;
    const fallbackReply = generateLocalChatFallback(code, messages, instruction, errorText);
    return res.json({ reply: `${notice}${fallbackReply}` });
  }
});

// REST endpoint: Verify Server Gemini AI Status (supports GET & POST with no-store caching)
app.all('/api/ai/status', async (req, res) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  const { aiClient, hasKey } = getAiClient(req);
  if (!hasKey) {
    return res.json({
      ok: false,
      model: 'local-pep8-engine',
      message: 'Máy chủ AI Studio chưa có GEMINI_API_KEY hợp lệ trong Settings > Secrets.',
    });
  }

  let lastError: any = null;

  for (const model of CANDIDATE_MODELS) {
    const tryPing = async (useThinking: boolean) => {
      const modelConfig: any = useThinking && supportsThinkingConfig(model)
        ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } }
        : undefined;
      return await withTimeout(
        aiClient.models.generateContent({
          model,
          contents: 'Ping',
          config: modelConfig,
        }),
        12000
      );
    };

    try {
      const response = await tryPing(true);
      if (response && response.text) {
        return res.json({
          ok: true,
          model,
          message: `Trợ lý Google Gemini sẵn sàng trên máy chủ (${model})!`,
        });
      }
    } catch (e: any) {
      const status = (e?.status as number) || (e?.statusCode as number);
      if (status === 400 && supportsThinkingConfig(model) && !isAuthOrPermissionError(e)) {
        try {
          const retryResp = await tryPing(false);
          if (retryResp && retryResp.text) {
            return res.json({
              ok: true,
              model,
              message: `Trợ lý Google Gemini sẵn sàng trên máy chủ (${model})!`,
            });
          }
        } catch (retryErr: any) {
          e = retryErr;
        }
      }
      lastError = e;
      if (isAuthOrPermissionError(e)) {
        break;
      }
    }
  }

  const errorInfo = extractFriendlyGeminiError(lastError);
  const redactedRaw = (errorInfo.raw || '').replace(/AIza[A-Za-z0-9_-]{10,}/g, '[REDACTED_KEY]');
  const rawEnvGemini = (process.env.GEMINI_API_KEY || '').trim();
  const rawEnvGoogle = (process.env.GOOGLE_API_KEY || '').trim();
  const rawEnvApiKey = (process.env.API_KEY || '').trim();
  return res.json({
    ok: false,
    model: CANDIDATE_MODELS[0],
    message: `${errorInfo.friendly} Ứng dụng không có ô nhập khóa thủ công; bộ phân tích PEP 8 nội bộ vẫn sẵn sàng ngoại tuyến.`,
    diagnostic: {
      httpStatus: errorInfo.code ?? null,
      keyPresent: hasKey,
      keySource: rawEnvGemini ? 'GEMINI_API_KEY' : (rawEnvGoogle ? 'GOOGLE_API_KEY' : 'NONE'),
      geminiKeyLen: rawEnvGemini.length,
      geminiKeyStartsAIza: rawEnvGemini.startsWith('AIza'),
      googleKeyLen: rawEnvGoogle.length,
      apiKeyLen: rawEnvApiKey.length,
      apiKeyStartsAIza: rawEnvApiKey.startsWith('AIza'),
      rawError: redactedRaw.slice(0, 350),
    },
  });
});

// REST endpoint: Terminal Diagnostic Logger for client/standalone AI errors
app.post('/api/ai/diagnostic-log', (req, res) => {
  const data = req.body || {};
  printTerminalAiDiagnostic({
    timestamp: data.timestamp,
    endpoint: data.endpoint || 'client-request',
    operation: data.operation || 'Client AI Call',
    failureType: data.failureType || 'UNKNOWN',
    httpStatus: data.httpStatus,
    errorMessage: data.errorMessage || 'No error details provided',
    keyValidation: data.keyValidation,
    remediation: data.remediation,
    source: 'client-terminal-dispatch',
  });
  res.status(200).json({ ok: true, logged: true });
});

// Setup Vite middleware in dev or static files in prod
async function startServer() {
  server.on('error', (err: any) => {
    console.error('[Server Error] HTTP Server error:', err);
  });

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve('dist');
    const indexPath = path.join(distPath, 'index.html');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(200).send('<!DOCTYPE html><html><head><title>Pydroid 3 Web</title></head><body>Pydroid 3 Web is running.</body></html>');
      }
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[Pydroid 3 Web] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[Server Fatal] Failed to start server:', err);
});
